import { Component } from '@angular/core';
import { LaptopService } from './laptop.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Laptop } from './model/Laptop';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'LMS-ANG';
  result : string="";
  billform:FormGroup;
  lap:Laptop;
  PcList : Laptop[]=[];


  constructor(private pc :LaptopService)
  {
this.billform = new FormGroup({

 id:new FormControl("", [Validators.required, Validators.pattern('[0-9]+')]),
 brand: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z ]+')]),
 model: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z 0-9]+')]),
 price: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')])
  })
  this.lap = new Laptop(); 
  this.GetAllDetails();
  }

  InsertPcDetails(data:any)
  {
    this.lap.id =data.id;
    this.lap.brand = data.brand;
    this.lap.model = data.model;
    this.lap.price = data.price;
    this.result = this.pc.insertDetails(this.lap);
    this.GetAllDetails();

    alert("Data Inserted"+data.id+" "+data.brand+" "+data.model+" "+data.price);

  }

  UpdatePcDetails(data:any)
  {
    this.lap.id =data.id;
    this.lap.brand = data.brand;
    this.lap.model = data.model;
    this.lap.price = data.price;
    this.result = this.pc.updateDetails(this.lap);
    this.GetAllDetails();
    alert("Data Updated"+data.id+" "+data.brand+" "+data.model+" "+data.price);

  }

  DeletePcDetails(data:any)
  {
    this.lap.id =data.id;
    this.result = this.pc.deleteDetails(this.lap);
    this.GetAllDetails();
    alert("Data Deleted");
  }




  GetAllDetails() {
    this.pc.getAllDetails().subscribe(laptopVal => this.PcList = laptopVal);
  } 
}
