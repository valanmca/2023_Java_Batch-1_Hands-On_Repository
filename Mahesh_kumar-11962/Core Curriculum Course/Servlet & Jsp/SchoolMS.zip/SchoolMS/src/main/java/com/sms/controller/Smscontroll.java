package com.sms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.bean.School;
import com.sms.dao.SchoolDAO;

/**
 * Servlet implementation class Smscontroll
 */
@WebServlet("/Smscontroll")
public class Smscontroll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		

		String reqFrom = request.getParameter("sms_btn");

		SchoolDAO dao = new SchoolDAO();
		if (reqFrom.equals("Insert")) {
			int sId = Integer.parseInt(request.getParameter("id"));
			String sName = request.getParameter("name");
			int sDno = Integer.parseInt(request.getParameter("dno"));

			School bean = new School(sId, sName, sDno);
			int insertRes = dao.insertStudent(bean);

			if (insertRes != 0) {
				response.sendRedirect("InsertSuccess.jsp");

			} else {
				response.sendRedirect("InsertFail.jsp");
			}
		}

	}

}
