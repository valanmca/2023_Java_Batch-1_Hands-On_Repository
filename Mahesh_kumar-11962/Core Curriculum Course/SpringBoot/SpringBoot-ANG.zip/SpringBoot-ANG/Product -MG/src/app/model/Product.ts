export class Product
{
    pid!:number;
    pname!:string;
    pcount!:number;
    pprice!:number;
}