package com.tms.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.tms.bean.*;
import com.tms.dao.TeacherDAO;

public class TeacherMain {
 
	static Scanner sc = new Scanner(System.in);

	public static int menu() {
		System.out.println("1.Insert Teacher Details\n2.Delete Teacher Details\n"
				+ "3.Update Teacher Details\n4.Search Teacher Details\n5.ViewAll Teacher Details\n6.Exit");
		return sc.nextInt();

	}

	public static Teacher insertTeacherDetails() {
		System.out.println("Enter the TeacherId,TeacherName,TeacherMail,TeacherQualification,TeacherLocation :");
		return new Teacher(sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.next());

	}

	public static int deleteTeacherDetails() {
		System.out.println("Enter the TeacherId you want to delete : ");
		return sc.nextInt();
	}

	public static Teacher updateTeacherDetails() {
		System.out.println(
				"Enter the TeacherId,TeacherName,TeacherMail,TeacherQualification,TeacherLocation you want to update:");
		return new Teacher(sc.nextInt(), sc.next(), sc.next(), sc.next(), sc.next());

	}

	public static int findTeacherDetails() {
		System.out.println("Enter the TeacherId you want to Search : ");
		return sc.nextInt();
	}

	public static void main(String[] args) {
		TeacherDAO dao = new TeacherDAO();
		String msg = "";
		do {
			switch (menu()) {
			case 1:

				if (dao.insertDetails(insertTeacherDetails()) == 1) {
					System.out.println("Data Insert Sucessfully");
				} else {
					System.out.println("Data Inserted Unsucessfully");
				}
				break;

			case 2:

				if (dao.deleteDetails(deleteTeacherDetails()) == 1) {
					System.out.println("Data Deleted Successfully");
				} else {
					System.out.println("Data Deleted Unsuccessfully");
				}

				break;

			case 3:
				if (dao.updateDetails(updateTeacherDetails()) == 1) {
					System.out.println("Data Updated Sucessfully");
				} else {
					System.out.println("Data Updated Unsucessfully");
				}
				break;

			case 4:
				int searchid = findTeacherDetails();
				Teacher bean = dao.findDetails(searchid);
				if (bean != null) {
					bean.display();
				} else {
					System.out.println("Data Not Found!");
				}
				break;

			case 5:
				List<Teacher> lst = dao.findAllDetails();
				for (Teacher obj : lst) {
					obj.display();
				}
				break;
			case 6:
				System.out.println("---Application exit Successfully");
				System.exit(0);

			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want repeat again [yes | no] : ");
			msg = sc.next();
		} while (msg.equalsIgnoreCase("yes"));

	}

}
