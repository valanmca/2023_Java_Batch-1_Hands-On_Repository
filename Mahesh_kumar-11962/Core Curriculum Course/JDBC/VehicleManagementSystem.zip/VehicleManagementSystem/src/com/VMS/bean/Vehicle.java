package com.VMS.bean;

public class Vehicle {

	int VehicleNo;
	String VehicleBrand;
	String VehicleModel;
	Double VehiclePrice;

	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(int vehicleNo, String vehicleBrand, String vehicleModel, Double vehiclePrice) {
		super();
		VehicleNo = vehicleNo;
		VehicleBrand = vehicleBrand;
		VehicleModel = vehicleModel;
		VehiclePrice = vehiclePrice;
	}

	public int getVehicleNo() {
		return VehicleNo;
	}

	public void setVehicleNo(int vehicleNo) {
		VehicleNo = vehicleNo;
	}

	public String getVehicleBrand() {
		return VehicleBrand;
	}

	public void setVehicleBrand(String vehicleBrand) {
		VehicleBrand = vehicleBrand;
	}

	public String getVehicleModel() {
		return VehicleModel;
	}

	public void setVehicleModel(String vehicleModel) {
		VehicleModel = vehicleModel;
	}

	public Double getVehiclePrice() {
		return VehiclePrice;
	}

	public void setVehiclePrice(Double vehiclePrice) {
		VehiclePrice = vehiclePrice;
	}

	
	public void display()
	{
		System.out.println("Vehicle Number : "+VehicleNo);
		System.out.println("Vehicle Brand : "+VehicleBrand);
		System.out.println("Vehicle Model : "+VehicleModel);
		System.out.println("Vehicle Price : "+VehiclePrice);
	}
	
	
}
