package com.VMS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.VMS.bean.Vehicle;
import com.VMS.util.DBConnect;

public class VmsDao {
	public int insertBikeDetails(Vehicle Bean) {
		int n = 0;
		try {
			Connection con = DBConnect.getDBconnection();
			String InsertQuery = "insert into BookVehicle values(?,?,?,?)";

			PreparedStatement ps = con.prepareStatement(InsertQuery);
			ps.setInt(1, Bean.getVehicleNo());
			ps.setString(2, Bean.getVehicleBrand());
			ps.setString(3, Bean.getVehicleModel());
			ps.setDouble(4, Bean.getVehiclePrice());
			
			n =ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}

		return n;
	}
	
	
	
	public int deleteBikeDetails(int bikeno)
	{
		int n =0;
		try {
			Connection con = DBConnect.getDBconnection();
			String DeleteQuery = "delete from BookVehicle where BikeNo=?";
			
			PreparedStatement ps = con.prepareStatement(DeleteQuery);
			ps.setInt(1,bikeno);
			
			n= ps.executeUpdate();
		} catch (Exception e) {
			
		}
		return n;
	}
	
	
	public List<Vehicle> viewallBikedetails(Vehicle bean)
	{
	List<Vehicle> lst = new ArrayList<Vehicle>();
		try
		{
			Connection con  = DBConnect.getDBconnection();
			String Viewquery = "select * from BookDetails";
			PreparedStatement ps = con.prepareStatement(Viewquery);
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				Vehicle bean1 = new Vehicle();
				bean1.setVehicleNo(rs.getInt("Bikeno"));
				bean1.setVehicleBrand(rs.getString("BikeBrand"));
				lst.add(bean1);
			}
		}
		catch (Exception e) {
		System.out.println(e);	
		}
		return lst;
	}

}
