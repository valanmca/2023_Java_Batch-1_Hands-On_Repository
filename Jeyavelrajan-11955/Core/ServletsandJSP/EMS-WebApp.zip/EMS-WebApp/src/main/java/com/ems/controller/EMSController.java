package com.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.bean.Employee;
import com.ems.dao.EmployeeDAO;




@WebServlet("/EMSController")
public class EMSController extends HttpServlet {
	EmployeeDAO dao = new EmployeeDAO();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		     String requestForm= request.getParameter("ems_button");
		     
		     
		     if(requestForm.equals("Insert Employee")) {
		    	 int id = Integer.parseInt(request.getParameter("eid"));
		    	 String name = request.getParameter("ename");
		    	 int salary = Integer.parseInt(request.getParameter("esalary"));
		    	 int Dno = Integer.parseInt(request.getParameter("Dno"));
		    	 
		    	 
		    	 Employee bean = new Employee(id,name,salary,Dno);
		    	 int  m = dao.insertEmployee(bean);
		    	 
		    	 
		    	 if(m == 1) {
		    		 response.sendRedirect("insertEmployeeSuccess.jsp");
		    	 }else {
		    		 response.sendRedirect("insertEmployeeFail.jsp");
		    	 }
		     }
		 
		     if(requestForm.equals("Update Employee")) {
		    	 int id = Integer.parseInt(request.getParameter("eid"));
		    	 String name = request.getParameter("ename");
		    	 int salary = Integer.parseInt( request.getParameter("esalary"));
		    	 int Dno = Integer.parseInt( request.getParameter("Dno"));
		    	 
		    	 
		    	 Employee bean = new Employee(id,name,salary,Dno);
		    	 int  m = dao.updateEmployee(bean);
		    	 
		    	 
		    	 if(m == 1) {
		    		 response.sendRedirect("updateEmployeeSuccess.jsp");
		    	 }else {
		    		 response.sendRedirect("updateEmployeeFail.jsp");
		    	 }
		     }
		     
		     if(requestForm.equals("Delete Employee")) {
		    	 int id = Integer.parseInt(request.getParameter("eid"));
		    	
		    	 int  m = dao.deleteEmployee(id);
		    	 
		    	 
		    	 if(m == 1) {
		    		 response.sendRedirect("deleteEmployeeSuccess.jsp");
		    	 }else {
		    		 response.sendRedirect("deleteEmployeeFail.jsp");
		    	 }
		     }
		     
		     if(requestForm.equals("Find Employee")) {
		    	 int id = Integer.parseInt(request.getParameter("eid"));
		    	
		    	 Employee bean = dao.findEmployee(id);
		    	 
		    	 RequestDispatcher rd = request.getRequestDispatcher("findEmployeeSuccess.jsp");
		    	 request.setAttribute("bean", bean);
		    	 rd.forward(request, response);

		     }
	}
		     @Override
//		 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		 	  List<Employee> list=dao.findAllEmployee();
//		 	  RequestDispatcher rd=request.getRequestDispatcher("findAllEmployee.jsp");
//		       request.setAttribute("list", list);
//		       rd.forward(request, response);
//		 	}
		  
		  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      String rid=request.getParameter("id");
//		      String rid1=request.getParameter("id");
//		      String rid2=request.getParameter("id");
		      
		      List<Employee> list=dao.findAllEmployee();
		      
		      if(rid.equals("a")) {
		          RequestDispatcher rd=request.getRequestDispatcher("deleteDoctor.jsp");
		          request.setAttribute("list", list);
		          rd.forward(request, response);
		          }
		      
		      if(rid.equals("b")) {
		          RequestDispatcher rd=request.getRequestDispatcher("findAllDoctor.jsp");
		          request.setAttribute("list", list);
		          rd.forward(request, response);
		          }
		      
		      if(rid.equals("c")) {
		      RequestDispatcher rd=request.getRequestDispatcher("findDoctor.jsp");
		      request.setAttribute("list", list);
		      rd.forward(request, response);
		      }
		     }

}


