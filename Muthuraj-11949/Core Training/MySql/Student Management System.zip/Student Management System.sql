create database student;
use student;
create table student( student_id int primary key,fname varchar(255),lname varchar(255),gender varchar(30),age int,contact_add int,emp_email varchar(255),emp_pass varchar(255));
create table Staff(staff_id int primary key,gender varchar(30),date_in Date,frist_name varchar(255),Last_name varchar(255),job_title varchar(250),Phone_number int,email_address varchar(255),other_staff_details varchar(255));
create table staff_Reserach_interests(staff_Id int, FOREIGN KEY(staff_Id) REFERENCES Staff(staff_Id),Area_of_reserach_id int primary key);
create table staff_on_Research_projects (Project_Id int, FOREIGN KEY(Project_Id) REFERENCES Reserach_Projects(project_Id),staff_Id int, FOREIGN KEY(staff_Id) REFERENCES Staff(staff_Id),date_in Date primary key);
create table Reserach_Projects(projrect_id int primary key,Area_of_reserach_id int, FOREIGN KEY(Area_of_reserach_id) REFERENCES staff_Reserach_interests(Area_of_reserach_id),Project_name varchar(200),Project_Description varchar(200),Other_details Varchar(200));
create table Staff_Course_Supervision(staff_Id int, FOREIGN KEY(staff_Id) REFERENCES Staff(staff_Id),course_offering_id int, FOREIGN KEY(course_offering_id) REFERENCES Course_offered(course_offering_id));
create table Course_offered(course_offering_id int primary key,course_offering_name varchar(200),other_course_offering_details varchar(200));
create table Course_Scheduled(course_Scheduled_id int primary key,course_offering_id int, FOREIGN KEY(course_offering_id) REFERENCES Course_offered(course_offering_id));
create table Student_Course_Registrations(student_Id int, FOREIGN KEY(student_Id) REFERENCES student(student_Id),course_Scheduled_id int, FOREIGN KEY(course_Scheduled_id ) REFERENCES Course_Scheduled(course_Scheduled_id ));

