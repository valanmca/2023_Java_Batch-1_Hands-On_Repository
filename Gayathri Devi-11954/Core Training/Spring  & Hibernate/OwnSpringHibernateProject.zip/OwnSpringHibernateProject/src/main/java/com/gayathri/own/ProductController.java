package com.gayathri.own;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gayathri.own.bean.ProductBean;
import com.gayathri.own.dao.ProductDao;

@Controller
public class ProductController {

	@Autowired
	ProductDao dao;

//view
	@RequestMapping("Header")
	public ModelAndView loadHead() {
		ModelAndView mv = new ModelAndView("Header");
		return mv;
	}
	
	@RequestMapping("Right")
	public ModelAndView loadRight() {
		ModelAndView mv = new ModelAndView("Right");
		return mv;
	}
	
	@RequestMapping("InsertProduct")
	public ModelAndView loadInsertProduct() {
		ModelAndView mv = new ModelAndView("InsertProduct");
		return mv;
	}
	
	@RequestMapping("UpdateProduct")
	public ModelAndView loadUpdateProduct() {
		List<Integer> list = dao.getIDList();
		ModelAndView mv = new ModelAndView("UpdateProduct");
		mv.addObject("idList", list);
		return mv;
	}
	
	@RequestMapping("DeleteProduct")
	public ModelAndView loadDeleteProduct() {
		List<Integer> list = dao.getIDList();
		ModelAndView mv = new ModelAndView("DeleteProduct");
		mv.addObject("idList", list);
		return mv;
	}
	
	@RequestMapping("SearchProduct")
	public ModelAndView loadSearchProduct() {
		List<Integer> list = dao.getIDList();
		ModelAndView mv = new ModelAndView("SearchProduct");
		mv.addObject("idList", list);
		return mv;
	}
	
//Actions
	@RequestMapping("PerformInsert")
	public ModelAndView performInsert(@ModelAttribute("bean") ProductBean bean) {
		dao.insertProduct(bean);
		ModelAndView mv = new ModelAndView("InsertSuccess");
		mv.addObject("bean",bean);
		return mv;		
	}
	
	@RequestMapping("PerformUpdate")
	public ModelAndView performUpdate(@ModelAttribute("bean") ProductBean bean) {
		dao.updateProduct(bean);
		ModelAndView mv = new ModelAndView("UpdateSuccess");
		mv.addObject("bean",bean);
		return mv;		
	}
	
	@RequestMapping("PerformDelete")
	public ModelAndView performDelete(@ModelAttribute("bean") ProductBean bean) {
		dao.deleteProduct(bean);
		ModelAndView mv = new ModelAndView("DeleteSuccess");
		mv.addObject("bean", bean);
		return mv;
	}
	
	@RequestMapping("PerformSearch")
	public ModelAndView performSearch(@ModelAttribute("bean") ProductBean bean) {
		ProductBean pro =dao.searchProduct(bean);
		ModelAndView mv = new ModelAndView("SearchSuccess");
		mv.addObject("pro",pro);
		return mv;		
	}

//view all
	@RequestMapping("performView")
	public ModelAndView loadViewAll() {
		List<ProductBean> proList = dao.performView();
		ModelAndView mv = new ModelAndView("ViewAll");
		mv.addObject("idList", proList);
		return mv;
	}
}
