package Day_3;

public class StringImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// string immutable this concept it is create new assign Object.
	
		
		String s1="java";
		s1=s1.concat("world");
		System.out.println(s1);//Java World
		
		
		s1=s1.toUpperCase();
		System.out.println(s1);//Java world 
		
		
		
	}

}
