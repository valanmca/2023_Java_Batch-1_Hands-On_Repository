package com.hms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_patient")
public class Hospital {

	@Id
	@Column(name="patient_id")
	private int patientId;
	
	@Column(name="patient_name")
	private String patientName;
	
	@Column(name="patient_disease_name")
	private String diseaseName;
	
	@Column(name="doctor_incharge_name")
	private  String doctorInchargeName;
	
	@Column(name="patient_ward")
	private int ward;
	
	@Column(name="patient_bill_amount")
	private int billAmount;

	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospital(int patientId, String patientName, String diseaseName, String doctorInchargeName, int ward,
			int billAmount) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.diseaseName = diseaseName;
		this.doctorInchargeName = doctorInchargeName;
		this.ward = ward;
		this.billAmount = billAmount;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	public String getDoctorInchargeName() {
		return doctorInchargeName;
	}

	public void setDoctorInchargeName(String doctorInchargeName) {
		this.doctorInchargeName = doctorInchargeName;
	}

	public int getWard() {
		return ward;
	}

	public void setWard(int ward) {
		this.ward = ward;
	}

	public int getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}

	@Override
	public String toString() {
		return "Hospital [patientId=" + patientId + ", patientName=" + patientName + ", diseaseName=" + diseaseName
				+ ", doctorInchargeName=" + doctorInchargeName + ", ward=" + ward + ", billAmount=" + billAmount + "]";
	}

	
	

	
	
	
}

