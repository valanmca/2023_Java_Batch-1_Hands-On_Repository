package com.modeltms.dao;

import org.springframework.data.repository.CrudRepository;

import com.modeltms.bean.ModelTeacher;

public interface ModelTeacherDao extends CrudRepository<ModelTeacher, Integer>{

}
