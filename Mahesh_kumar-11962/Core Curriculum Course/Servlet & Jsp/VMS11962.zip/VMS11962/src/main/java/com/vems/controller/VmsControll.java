package com.vems.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vems.bean.Vehicle;
import com.vems.dao.VehicleDAO;

/**
 * Servlet implementation class VmsControll
 */
@WebServlet("/VmsControll")
public class VmsControll extends HttpServlet {

	VehicleDAO dao = new VehicleDAO();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String reqFrom = request.getParameter("vemsbtn");

		if (reqFrom.equals("Insert")) {
			int id = Integer.parseInt(request.getParameter("vid"));
			String type = request.getParameter("vtype");
			String name = request.getParameter("vname");
			int number = Integer.parseInt(request.getParameter("vno"));
			String owner = request.getParameter("vowner");

			Vehicle bean = new Vehicle(id, number, type, name, owner);

			int resResult = dao.insertVehicleDetails(bean);

			if (resResult == 1) {
				response.sendRedirect("InsertSuccess.jsp");
			} else {
				response.sendRedirect("InsertFail.jsp");
			}
		}

		if (reqFrom.equals("Delete")) {
			int id = Integer.parseInt(request.getParameter("vid"));

			int delResult = dao.deleteVehicleDetails(id);

			if (delResult == 1) {
				response.sendRedirect("DeleteSuccess.jsp");
			} else {
				response.sendRedirect("DeleteFail.jsp");
			}

		}

		if (reqFrom.equals("Update")) {

			int id = Integer.parseInt(request.getParameter("vid"));
			String type = request.getParameter("vtype");
			String name = request.getParameter("vname");
			int number = Integer.parseInt(request.getParameter("vno"));
			String owner = request.getParameter("vowner");

			Vehicle bean = new Vehicle(id, number, type, name, owner);

			int resResult = dao.updateVehicleDetails(bean);

			if (resResult == 1) {
				response.sendRedirect("UpdateSuccess.jsp");
			} else {
				response.sendRedirect("UpdateFail.jsp");
			}
		}

		if (reqFrom.equals("Search")) {
			int id = Integer.parseInt(request.getParameter("vid"));

			Vehicle bean = dao.searchVehicle(id);

			RequestDispatcher rd = request.getRequestDispatcher("FindResult.jsp");
			request.setAttribute("bean", bean);
			rd.forward(request, response);

		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<Vehicle> lst = new ArrayList<Vehicle>();
		lst = dao.viewallVehicleDetails();
		RequestDispatcher rd = request.getRequestDispatcher("ViewAllPage.jsp");
		request.setAttribute("msg", lst);
		rd.forward(request, response);

	}

}
