
export class Employee {
    id!: number;
    name!: string;
    depno!:number;
    salary!: number;
}