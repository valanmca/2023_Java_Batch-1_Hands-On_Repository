package com.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tms.bean.Teacher;
import com.tms.util.DBUtil;

public class TeacherDAO {
	public int insertTeacher(Teacher bean) {
		   int n=0;
		   try {
			   Connection con = DBUtil.getDBConnection();
			   String sql = "insert into tbl_teacher values(?,?,?,?,?)";
			   PreparedStatement ps = con.prepareStatement(sql);
			   ps.setInt(1, bean.getTeacherId());
			   ps.setString(2,bean.getTeacherName());
			   ps.setString(3,bean.getTeacherEmail());
			   ps.setString(4,bean.getTeacherQualification());
			   ps.setString(5,bean.getTeacherLocation());
			 
			   n = ps.executeUpdate();
		   }catch(Exception e) {
			   System.out.println(e);
		   }
		   return n;
	   }

	public int deleteTeacher(int id) {
		   int n=0;
		   try {
			   Connection con = DBUtil.getDBConnection();
			   String sql = "delete from tbl_teacher where teacherId = ?";
			   PreparedStatement ps = con.prepareStatement(sql);
			   ps.setInt(1,id);
			   n = ps.executeUpdate();
		   }catch(Exception e) {
			   System.out.println();
		   }
		   return n;
	}
	public int updateTeacher(Teacher bean) {
		int n1=0;
		try {
		Connection con = DBUtil.getDBConnection();
		   String sql = "update tbl_teacher set teacherName =?,teacherEmail =? ,teacherQualification =?,teacherLocation =? where teacherId =?";
		   PreparedStatement ps = con.prepareStatement(sql);
		   ps.setString(1,bean.getTeacherName());
		   ps.setString(2,bean.getTeacherEmail());
		   ps.setString(3,bean.getTeacherQualification());
		   ps.setString(4, bean.getTeacherLocation());
		   ps.setInt(5, bean.getTeacherId());
		   n1 = ps.executeUpdate();
	      }catch(Exception e) {
		   System.out.println();
	      }
		return n1;
		
	}

	public Teacher findTeacher(int id) {
		   Teacher bean =null;
		   try {
			   Connection con = DBUtil.getDBConnection();
			   String sql = "select * from tbl_teacher where teacherId = ?";
			   PreparedStatement ps = con.prepareStatement(sql);
			   ps.setInt(1,id);
			   ResultSet rs = ps.executeQuery();
			   if(rs.next()) {
				   bean =new Teacher();
				   bean.setTeacherId(rs.getInt("teacherId"));
				   bean.setTeacherName(rs.getString("teacherName"));
				   bean.setTeacherEmail(rs.getString("teacherEmail"));
				   bean.setTeacherQualification(rs.getString("teacherQualification"));
				   bean.setTeacherLocation(rs.getString("teacherLocation"));
			   }
		   }catch(Exception e) {
			   System.out.println();
		   }
		   return bean;
	}

	public List<Teacher> findAllTeacher() {
		List<Teacher> list = new ArrayList<Teacher>();
		  
		   try {
			   Connection con = DBUtil.getDBConnection();
			   String sql = "select * from tbl_teacher";
			   PreparedStatement ps = con.prepareStatement(sql);
			   ResultSet rs = ps.executeQuery();
			   while(rs.next()) {
				   Teacher bean =new Teacher();
				   bean.setTeacherId(rs.getInt("teacherId"));
				   bean.setTeacherName(rs.getString("teacherName"));
				   bean.setTeacherEmail(rs.getString("teacherEmail"));
				   bean.setTeacherQualification(rs.getString("teacherQualification"));
				   bean.setTeacherLocation(rs.getString("teacherLocation"));
				   list.add(bean);		   
			   }
		   }catch(Exception e) {
			   System.out.println(e);
		   }
		   return list;
	}

}
