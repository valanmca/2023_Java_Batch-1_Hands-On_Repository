package com.mms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbMmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbMmsApplication.class, args);
	}

}
