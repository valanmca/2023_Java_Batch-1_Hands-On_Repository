package com.ems.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_emp")
public class Employee {
	@jakarta.persistence.Id
	@Column(name = "eId")
	private int eId;
	@Column(name = "eName")
	private String eName;
	@Column(name = "eSalary")
	private int eSalary;
	@Column(name = "eDno")
	private int eDno;

	public Employee() {
		super();

	}

	public Employee(int eId, String eName, int eSalary, int eDno) {
		super();
		this.eId = eId;
		this.eName = eName;
		this.eSalary = eSalary;
		this.eDno = eDno;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public int geteSalary() {
		return eSalary;
	}

	public void seteSalary(int eSalary) {
		this.eSalary = eSalary;
	}

	public int geteDno() {
		return eDno;
	}

	public void seteDno(int eDno) {
		this.eDno = eDno;
	}

	@Override
	public String toString() {
		return "Employee [eId=" + eId + ", eName=" + eName + ", eSalary=" + eSalary + ", eDno=" + eDno + "]";
	}

}