import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EmpServiceService } from './emp-service.service';
import { Employee } from './model/Employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'MG-SYS';

  myForm: FormGroup;
  employee: Employee;
  result: string = "";
  empList: Employee[] = [];

  constructor(private emp: EmpServiceService) {

    this.myForm = new FormGroup({
      id: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
      name: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z]+')]),
      depno: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
      salary: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')])
    })

    this.employee = new Employee();
    this.getAllEmployees();
    
}


InsertEmployee(data: any) {
  this.employee.id = data.id;
  this.employee.name = data.name;
  this.employee.depno = data.depno;
  this.employee.salary = data.salary;
  this.result = this.emp.InsertEmployee(this.employee);

  alert(data.id+" "+data.name+" "+data.depno+" "+data.salary+" Data Inserted")
  this.getAllEmployees();
//  this.flag_insert=true;
}

DeleteEmployee(data: any) {
  alert(data.id+" Deleted ");
  this.employee.id = data.id;
 // this.employee.name = data.name;
  //this.employee.depno =data.depno;
  //this.employee.salary = data.salary;
  this.result = this.emp.DeleteEmployee(this.employee);
  this.getAllEmployees();
 // this.flag_delete=true;
}

UpdateEmployee(data: any) {
  alert("UpdatedData" + data.id + " " + data.name + " " +data.depno+" "+ data.salary);
  this.employee.id= data.id;
  this.employee.name = data.name;
  this.employee.depno = data.depno;
  this.employee.salary = data.salary;
  this.result = this.emp.UpdateEmployee(this.employee);
  this.getAllEmployees();
   //this.flag_update=true;

 }


getAllEmployees() {
  this.emp.getAllEmployeeDetails().subscribe(employees => this.empList = employees);
} 
}
