package com.lms.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.DeleteExchange;

import com.lms.bean.Course;
import com.lms.bean.Enrollment;
import com.lms.repo.EnrollementRepository;
import com.lms.service.EnrollmentService;

@RestController
public class EnrollController {
	
	EnrollmentService enrol;
	
	@PostMapping("/performEnroll")
	public String performInsert(@ModelAttribute Enrollment course) {
		enrol.enroll(course);
		return "Enrolled";
	}
/*	
	@PutMapping("/performUpdateCourse")
	public String performUpdate(@ModelAttribute Course course) {
		enrol.insertAndUpdateCourse(course);
		return "Updated";
	}
*/
	@DeleteExchange("/performUnenroll/{enrollment_id}")
	public String performDelete(@PathVariable("enrollment_id") long id) {
		enrol.unenroll(id);
		return " Deleted";
	}
	
	@GetMapping("/ViewAllEnrollment")
	public List<Enrollment> getAll() {
		Iterator<Enrollment> it =  enrol.getAll().iterator();
		List<Enrollment> list = new ArrayList<Enrollment>();
		while(it.hasNext()) {
			list.add(it.next());
		}
		return list;
	}
	


}
