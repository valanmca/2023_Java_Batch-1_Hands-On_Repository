package com.sms.bean;

public class Student {
	private int StudentRollNo;
	private String StudentName;
	private String StudentEmail;
	private String Standard;
	private String Location;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Student(int studentRollNo, String studentName, String studentEmail, String standard, String location) {
		super();
		StudentRollNo = studentRollNo;
		StudentName = studentName;
		StudentEmail = studentEmail;
		Standard = standard;
		Location = location;
	}


	public int getStudentRollNo() {
		return StudentRollNo;
	}

	public void setStudentRollNo(int studentRollNo) {
		StudentRollNo = studentRollNo;
	}

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}

	public String getStudentEmail() {
		return StudentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		StudentEmail = studentEmail;
	}

	public String getStandard() {
		return Standard;
	}

	public void setStandard(String standard) {
		Standard = standard;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

    public void display() {
    	System.out.println("----------------------------------");
    	System.out.println("Student RollNo is ->"+StudentRollNo);
    	System.out.println("Student Name is ->"+StudentName);
    	System.out.println("Student Email is ->"+StudentEmail);
    	System.out.println("Student Standard is ->"+Standard);
    	System.out.println("Student Location is ->"+Location);
    	System.out.println("-----------------------------------");
    	
    }



}
