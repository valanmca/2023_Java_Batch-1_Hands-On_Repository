package com.gayathri;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/*
//bean class using mapping
public class Employee {
	private int id;
	private String name;
	private int salary;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	

//bean class using Annotation
@Entity
@Table(name = "tbl_employee")
public class Employee {

	@Id
	
	@Column(name = "e_id")
	private int id;
	
	@Column(name = "e_name")
	private String name;
	
	@Column(name = "e_salary")
	private int salary;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
*/
@NamedQueries({
	@NamedQuery(name="SelectAllEmployee",query="from Employee")
})

@Entity
@Table(name = "tbl_employee")
public class Employee {

	@Id
	
	@Column(name = "e_id")
	private int id;
	
	@Column(name = "e_name")
	private String name;
	
	@Column(name = "e_salary")
	private int salary;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}

}
