package com.egs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MgsysAngApplication {

	public static void main(String[] args) {
		SpringApplication.run(MgsysAngApplication.class, args);
	}

}
