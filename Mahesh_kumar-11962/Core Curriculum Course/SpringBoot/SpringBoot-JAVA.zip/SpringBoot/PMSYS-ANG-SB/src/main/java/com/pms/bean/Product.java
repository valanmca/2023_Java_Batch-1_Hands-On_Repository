package com.pms.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_product")
public class Product {

	@Id
	@Column(name="pid")
	private int pid;
	@Column(name="pname")
	private String pname;
	@Column(name="pcount")
	private int pcount;
	@Column(name="pprice")
	private int pprice;
	
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Product(int pid, String pname, int pcount, int pprice) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pcount = pcount;
		this.pprice = pprice;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public String getPname() {
		return pname;
	}


	public void setPname(String pname) {
		this.pname = pname;
	}


	public int getPcount() {
		return pcount;
	}


	public void setPcount(int pcount) {
		this.pcount = pcount;
	}


	public int getPprice() {
		return pprice;
	}


	public void setPprice(int pprice) {
		this.pprice = pprice;
	}


	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pcount=" + pcount + ", pprice=" + pprice + "]";
	}
	
	
	
}
