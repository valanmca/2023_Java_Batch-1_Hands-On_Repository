package com.vems.bean;

public class Vehicle {

	// : Vehicle Id, Vehicle Type, Vehicle Name, Vehicle Number and Owner Name.
	private int VehicleId;
	private int VehicleNumber;
	private String VehicleType;
	private String VehicleName;
	private String OwnerName;

	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(int vehicleId, int vehicleNumber, String vehicleType, String vehicleName, String ownerName) {
		super();
		VehicleId = vehicleId;
		VehicleNumber = vehicleNumber;
		VehicleType = vehicleType;
		VehicleName = vehicleName;
		OwnerName = ownerName;
	}

	public int getVehicleId() {
		return VehicleId;
	}

	public void setVehicleId(int vehicleId) {
		VehicleId = vehicleId;
	}

	public int getVehicleNumber() {
		return VehicleNumber;
	}

	public void setVehicleNumber(int vehicleNumber) {
		VehicleNumber = vehicleNumber;
	}

	public String getVehicleType() {
		return VehicleType;
	}

	public void setVehicleType(String vehicleType) {
		VehicleType = vehicleType;
	}

	public String getVehicleName() {
		return VehicleName;
	}

	public void setVehicleName(String vehicleName) {
		VehicleName = vehicleName;
	}

	public String getOwnerName() {
		return OwnerName;
	}

	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}

}
