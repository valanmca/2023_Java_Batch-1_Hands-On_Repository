package com.ems.main;

import java.util.List;
import java.util.Scanner;

import com.ems.bean.Employee;
import com.ems.dao.EmployeeDAO;

public class EMSMainClass {

	static Scanner sc = new Scanner(System.in);

	public static int Menu() {
		System.out.println("1.Insert 2.Delete 3.Update 4.Find 5.Find All, 6.Exit");
		System.out.println("Enter your choice : ");
		return sc.nextInt();

	}

	public static Employee insertEmployee() {
		System.out.println("Enter employee id,name and dno : ");
		return new Employee(sc.nextInt(), sc.next(), sc.nextInt());
	}

	public static int DeleteEmployee() {
		System.out.println("Enter employee id to delete : ");
		return sc.nextInt();
	}

	public static Employee UpdateEmployee() {
		System.out.println("Enter employee Id,Name,deptId to update : ");
		return new Employee(sc.nextInt(), sc.next(), sc.nextInt());
	}

	private static int FindEmployee() {
		System.out.println("Enter employee id to find : ");
		return sc.nextInt();

	}

	public static void main(String[] args) {
		EmployeeDAO dao = new EmployeeDAO();
		String msg = "";
		do {
			switch (Menu()) {
			case 1:

				if (dao.insertEmployee(insertEmployee()) == 1) {
					System.out.println("Record Inserted");
				} else {
					System.out.println("Record not inserted");
				}
				break;

			case 2:
				int id = DeleteEmployee();
				int n = dao.deleteEmployee(id);
				if (n == 1) {
					System.out.println("Record Deleted");
				} else {
					System.out.println("Record Not Deleted");
				}
				break;

			case 3:
				Employee emp = UpdateEmployee();
				int n1 = dao.updateEmployee(emp);
				if (n1 == 1) {
					System.out.println("Record Updated");
				} else {
					System.out.println("Record not Updated");
				}
				break;

			case 4:
				int id1 = FindEmployee();
				Employee bean = dao.findEmloyee(id1);
				if (bean != null) {
					bean.display();
				} else {
					System.out.println("Null Data");
				}
				break;

			case 5:

				List<Employee> list = dao.viewallEmployee();
				for (Employee e : list) {
					e.display();
				}

				break;

			case 6:
				System.out.println(" ---   program was terminated sucessfully  ---");
				System.exit(0);
				break;

			default:
				System.out.println("\nWrong Selection - ' Select 1 to 6 options only '");
			}

			System.out.println("\nDo you want to continue [Yes|No] : ");
			msg = sc.next();
		} while (msg.equalsIgnoreCase("yes"));

	}

}
