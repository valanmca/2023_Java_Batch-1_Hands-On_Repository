package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.sms.bean.Student;
import com.sms.util.DBUtil;

public class StudentDAO {
	
	public int  insertStudent(Student bean) {
		int n=0;
		try {
			Connection con = DBUtil.getDBConnection();
			String Sql = "insert into Student values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(Sql);
			ps.setInt(1, bean.getStudentRollNo());
			ps.setString(2, bean.getStudentName());
			ps.setString(3,bean.getStudentEmail());
			ps.setString(4, bean.getStandard());
			ps.setString(5, bean.getLocation());
			n = ps.executeUpdate();
		}catch(Exception e){
			System.out.println(e);
		}
		return n;
	}
	
	public int deleteStudent(int StudentRollNo) {
		int n=0;
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "Delete from Student where StudentRollNo = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, StudentRollNo);
			n=ps.executeUpdate();
		}catch(Exception e) {
			System.out.println(e);
		}
		return n;
	}
	public int updateStudent(Student bean) {
		int n1=0;
		try {
			Connection con = DBUtil.getDBConnection();
			String Sql = "update Student set  StudentName =? ,StudentEmail =?, Standard = ?, Location = ? where StudentRollNo = ?";
			PreparedStatement ps = con.prepareStatement(Sql);
			
			ps.setString(1, bean.getStudentName());
			ps.setString(2,bean.getStudentEmail());
			ps.setString(3, bean.getStandard());
			ps.setString(4, bean.getLocation());
			ps.setInt(5, bean.getStudentRollNo());
			n1 = ps.executeUpdate();
		}catch(Exception e){
			System.out.println(e);
		}
		return n1;
	}
	public Student findStudent(int StudentRollNo) {
		Student bean = null;
		try {
			Connection con = DBUtil.getDBConnection();
			String sql = "Select * from Student where StudentRollNo = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, StudentRollNo);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				bean = new Student();
				bean.setStudentRollNo(rs.getInt("StudentRollNo"));
				bean.setStudentName(rs.getString("StudentName"));
				bean.setStudentEmail(rs.getString("StudentEmail"));
				bean.setStandard(rs.getString("Standard"));
				bean.setLocation(rs.getString("Location"));
				
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return bean;
		
	}
	public List <Student> findAllStudent(){
		List<Student> list = new ArrayList<Student>();
		  
		   try {
			   Connection con = DBUtil.getDBConnection();
			   String sql = "select * from Student";
			   PreparedStatement ps = con.prepareStatement(sql);
			   ResultSet rs = ps.executeQuery();
			   while(rs.next()) {
				    Student bean = new Student();
					bean.setStudentRollNo(rs.getInt("StudentRollNo"));
					bean.setStudentName(rs.getString("StudentName"));
					bean.setStudentEmail(rs.getString("StudentEmail"));
					bean.setStandard(rs.getString("Standard"));
					bean.setLocation(rs.getString("Location"));
					list.add(bean);
				}
			}catch(Exception e) {
				System.out.println(e);
			}
		   return list;
		
	}

}
