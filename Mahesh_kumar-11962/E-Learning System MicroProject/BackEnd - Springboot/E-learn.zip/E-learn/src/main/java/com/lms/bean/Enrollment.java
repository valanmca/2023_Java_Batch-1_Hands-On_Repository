package com.lms.bean;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_enroll")
public class Enrollment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long enrollmentId;
	
	@ManyToOne
	private Course courseId;
	
	@ManyToOne
	private User userId;

	public Enrollment(long enrollmentId, Course courseId, User userId) {
		super();
		this.enrollmentId = enrollmentId;
		this.courseId = courseId;
		this.userId = userId;
	}

	public long getEnrollmentId() {
		return enrollmentId;
	} 

	public void setEnrollmentId(long enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public Course getCourseId() {
		return courseId;
	}

	public void setCourseId(Course courseId) {
		this.courseId = courseId;
	}

	public User getUserId() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}

	
}
