package com.hms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	public static Connection getDBconnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/MG_SYSTEM", "root", "Pa55w0rd@2k23");
			// jdbc:mysql://localhost:portno/DB name, Username, password .
		} catch (Exception e) {

			System.out.println(e);
		}
		return con;
	}

}
