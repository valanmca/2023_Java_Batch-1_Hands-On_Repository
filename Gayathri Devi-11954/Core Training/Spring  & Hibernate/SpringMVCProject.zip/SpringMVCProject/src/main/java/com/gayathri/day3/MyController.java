package com.gayathri.day3;

import java.net.http.HttpResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gayathri.day3.bean.Addition;
import com.gayathri.day3.bean.CalculatorService;
import com.gayathri.day3.bean.Employee;

@Controller
public class MyController {

	@RequestMapping("Welcome")
	public ModelAndView sayWelcome() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Welcome");
		return mv;
	}

	@RequestMapping("Hello")
	public ModelAndView sayHello() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Hello");
		mv.addObject("fname", "Gayathri");
		return mv;
	}

//	@RequestMapping("/")
//	public void sayAddtion(HttpServletRequest req, HttpServletResponse resp) {
//		if(req.getParameter("btn")!=null) {
//			int a=Integer.parseInt(req.getParameter("n1"));
//			int b=Integer.parseInt(req.getParameter("n2"));
//			int c=a+b;
//		System.out.println("Result : "+c);			
//		}	
//	}

	@RequestMapping("Input")
	public ModelAndView callInputPage() {
		ModelAndView mv = new ModelAndView("Input");
		return mv;
	}

	@RequestMapping("Addition")
	public ModelAndView performAddition(@ModelAttribute("addition") Addition addition) {
		ModelAndView mv = new ModelAndView("Result");
//		int sum=addition.getN1() + addition.getN2();
//		mv.addObject("sum",sum);
		mv.addObject("bean", addition);
		return mv;
	}

	@RequestMapping("EmployeeInput") // reading
	public ModelAndView callEmployeeInputPage() {
		ModelAndView mv = new ModelAndView("EmployeeInput");
		return mv;
	}

	@RequestMapping("AddEmployee") // output
	public ModelAndView addEmployee(@ModelAttribute("employee") Employee employee) { // Employee - bean class
																						// name,employee-object
		ModelAndView mv = new ModelAndView("EmployeeResult");// output page
//		int sum=addition.getN1() + addition.getN2();
//		mv.addObject("sum",sum);
		mv.addObject("emp", employee);
		return mv;
	}

	@RequestMapping("CalculatorInput")
	public ModelAndView callCalculatorInputPage() {
		ModelAndView mv = new ModelAndView("CalculatorInput");
		return mv;
	}

	@RequestMapping("calculatorAction")
	public ModelAndView performCalculate(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("calc") CalculatorService calc) {
		ModelAndView mv = new ModelAndView("CalculatorResult");
		String action = req.getParameter("btn");
		if (action.equals("Addition")) {
			int add = calc.getN1() + calc.getN2();
			mv.addObject("add", calc);
		}
		else if(action.equals("Subtraction")) {
		int sub = calc.getN1() - calc.getN2();
		mv.addObject("sub", calc);
		}
		else if(action.equals("Multiplication")) {
		int mul = calc.getN1() * calc.getN2();
		mv.addObject("mul", calc);
		}
		else if(action.equals("Division")) {
		int div = calc.getN1() / calc.getN2();
		mv.addObject("divi", calc);
		}
		
//		mv.addObject("obj",calc);
		return mv;
	}

}
