package com.tms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tms.bean.Teacher;
import com.tms.dao.TeacherDAO;


@WebServlet("/TMSController")
public class TMSController extends HttpServlet {
	
       TeacherDAO dao= new TeacherDAO();
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		 String requestForm= request.getParameter("ems_button");
     if(requestForm.equals("Insert Teacher")) {
    	 int id = Integer.parseInt(request.getParameter("tid"));
    	 String name = request.getParameter("tname");
    	 String email = request.getParameter("temail");
    	 String qualification =request.getParameter("tqualification");
    	 String location = request.getParameter("tlocation");
    	 
    	 
    	 Teacher bean = new Teacher(id,name,email,qualification,location);
    	 int  m = dao.insertTeacher(bean);
    	 
    	 
    	 if(m == 1) {
    		 response.sendRedirect("insertTeacherSuccess.jsp");
    	 }else {
    		 response.sendRedirect("insertTeacherFail.jsp");
    	 }
     }
 
     if(requestForm.equals("Update Teacher")) {
    	 int id = Integer.parseInt(request.getParameter("tid"));
    	 String name = request.getParameter("tname");
    	 String email = request.getParameter("temail");
    	 String qualification =request.getParameter("tqualification");
    	 String location = request.getParameter("tlocation");
    	 
    	 
    	 
    	 Teacher bean = new Teacher(id,name,email,qualification,location);
    	 int  m = dao.updateTeacher(bean);
    	 
    	 
    	 if(m == 1) {
    		 response.sendRedirect("updateTeacherSuccess.jsp");
    	 }else {
    		 response.sendRedirect("updateTeacherFail.jsp");
    	 }
     }
     
     if(requestForm.equals("Delete Teacher")) {
    	 int id = Integer.parseInt(request.getParameter("tid"));
    	
    	 int  m = dao.deleteTeacher(id);
    	 
    	 
    	 if(m == 1) {
    		 response.sendRedirect("deleteTeacherSuccess.jsp");
    	 }else {
    		 response.sendRedirect("deleteTeacherFail.jsp");
    	 }
     }
     
     if(requestForm.equals("Find Teacher")) {
    	 int id = Integer.parseInt(request.getParameter("tid"));
    	
    	 Teacher bean = dao.findTeacher(id);
    	 
    	 RequestDispatcher rd = request.getRequestDispatcher("findTeacherSuccess.jsp");
    	 request.setAttribute("bean", bean);
    	 rd.forward(request, response);

     }
}
     @Override
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String rid=request.getParameter("id");
//      String rid1=request.getParameter("id");
//      String rid2=request.getParameter("id");
      
      List<Teacher> list=dao.findAllTeacher();
      
      if(rid.equals("a")) {
          RequestDispatcher rd=request.getRequestDispatcher("deleteTeacher.jsp");
          request.setAttribute("list", list);
          rd.forward(request, response);
          }
      
      if(rid.equals("b")) {
          RequestDispatcher rd=request.getRequestDispatcher("findAllTeacher.jsp");
          request.setAttribute("list", list);
          rd.forward(request, response);
          }
      
      if(rid.equals("c")) {
      RequestDispatcher rd=request.getRequestDispatcher("findTeacher.jsp");
      request.setAttribute("list", list);
      rd.forward(request, response);
      }
     }

}
