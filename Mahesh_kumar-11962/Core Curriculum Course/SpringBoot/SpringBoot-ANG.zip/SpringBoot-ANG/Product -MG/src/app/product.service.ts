import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Product } from './model/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  private url:string="http://localhost:1000"
  constructor(private http: HttpClient) { }

  InsertProduct(product: Product) {
    this.http.post(this.url + "/PerformInsert", product).subscribe();
    return "Record Inserted";
  }

  DeleteProduct(product: Product) {
    this.http.delete(this.url + "/PerformDelete/" + product.pid).subscribe();
    return "Record Deleted";
  }

  UpdateProduct(product: Product)
  {
    this.http.put(this.url+"/PerformUpdate",product).subscribe();
    return "Record Updated";
  }

  getAllProductDetails() {
    return this.http.get<Product[]>(this.url + "/ViewAll");
  }
}
