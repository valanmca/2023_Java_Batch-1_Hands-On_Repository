package com.ems.controller;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EMSController {

	@RequestMapping("/start")
	public ModelAndView loadStartingPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("LandingPage");
		return mv;
	}
	
	@RequestMapping("/Links")
	public ModelAndView loadLinksPage()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Links");
		return mv;
	}
	
	@RequestMapping("/Insert")
	public ModelAndView loadInsertPage()
	{
		ModelAndView mv = new ModelAndView();
	mv.setViewName("");
		return mv;
	}
	
    @RequestMapping("/InsertEmployee")
    public ModelAndView loadInsertEmployeePage() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("InsertEmployee");
        return mv;
    }
    
    
    @RequestMapping("/PerformInsert")
    public ModelAndView performInsert(Employee emp) {
        dao.save(emp);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("InsertEmployeeSuccess");
        mv.addObject("bean", emp);
        return mv;
    }
	
}