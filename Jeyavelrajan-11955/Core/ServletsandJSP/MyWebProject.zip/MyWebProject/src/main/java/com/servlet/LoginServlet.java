package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("Uname");
		String password = request.getParameter("pwd");
		
		PrintWriter out = response.getWriter();
	
//		if(userName.equals("Admin")&& password.equals("123"))
		
		//Method 1	
//		out.println("<font color='green'><b> Welcome Admin </b> </font>");
			
	    //Method 2
//		response.sendRedirect("LoginSuccess.jsp?username="+userName);
//
//		else
//			out.println("<font color='red'><b> Invalid Form</b></font>");
//			response.sendRedirect("LoginFail.jsp?pass=+password");
//		out.close();
			
		//Method 3
		if(password.equals("123")) {
			RequestDispatcher rd = request.getRequestDispatcher("LoginSuccess.jsp");
			request.setAttribute("userName", userName);
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
//			request.setAttribute("msg", "Invalid user name Or password " );
			rd.include(request, response);
			out.println("<font color='red'> <b>Invalid UserName or Password</b></font>");
		}
			out.close();
	}
	
	

}
