package com.mahesh;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;



public class MainClass {
	
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction tn=session.beginTransaction();
//		
//  	Insert Data
//    
//    	Employee emp=new Employee();
//		emp.setId(103);
//		emp.setName("Jeban");
//		emp.setSalary(4000);
//		session.save(emp);
//		tn.commit();
	
   
		
  /*	Select  All
    
		String hql = "from Employee";
		Query<Employee> query=session.createQuery(hql); 
		List<Employee> list = query.list();
		for(Employee e: list) 
		{
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());	
		}
		tn.commit();
	*/
		
	/*
	 
	 *  Select particular id
	  
		String hql = "from Employee where id=102";
		Query<Employee> query=session.createQuery(hql); 
		List<Employee> list = query.list();
		for(Employee e: list) 
		{
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());	
		}
		tn.commit();
	*/
		
	/*
	 * 	Select Particular id Dynamically
		
		String hql = "from Employee where id=:val";
		Query<Employee> query=session.createQuery(hql); 
		query.setParameter("val", 101);
		List<Employee> list = query.list();
		for(Employee e: list) 
		{
		System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());	
		}
		tn.commit();
	*/
	
	/*  Update Data
	 
		String hql = "update Employee set name=:n where id=:i";
		Query<Employee> query=session.createQuery(hql); 
		query.setParameter("n","karthi" );
		query.setParameter("i", 101);
		int n = query.executeUpdate();
		
		if(n==1)
		{
			System.out.println("Record Updated");
		}
		else
		{
			System.out.println("Record Not Updated");
		}
		
	
		
		 
			String hql1 = "delete Employee where id=:i";
			Query<Employee> querystr=session.createQuery(hql1); 
			querystr.setParameter("i", 104);
			int n = querystr.executeUpdate();
			
			if(n==1)
			{
				System.out.println("Record Deleted");
			}
			else
			{
				System.out.println("Record Not Deleted");
			}
		*/
			
		
		// HCQL
		
		//Select All
		
	/*	Criteria query = session.createCriteria(Employee.class);
		List<Employee> list = query.list();
		for(Employee e: list)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		}
		tn.commit();
*/
		// Select the records with conditions.
/*		
		Criteria query = session.createCriteria(Employee.class);
		query.add(Restrictions.eq("id", 103));
		List<Employee> list = query.list();
		for(Employee e: list)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		}
		tn.commit();
*/
		
//		--------*--------
/*	
		Criteria query = session.createCriteria(Employee.class);
		query.add(Restrictions.gt("salary", 4000));
		List<Employee> list = query.list();
		for(Employee e: list)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		}
		tn.commit();
*/
		
//		--------*--------
/*
		Criteria query = session.createCriteria(Employee.class);
		query.add(Restrictions.lt("id", 104));
		List<Employee> list = query.list();
		for(Employee e: list)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		}
		tn.commit();
*/

/*
		Criteria query = session.createCriteria(Employee.class);
		query.add(Restrictions.like("name","k%"));
		List<Employee> list = query.list();
		for(Employee e: list)
		{
			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
		}
		tn.commit();
*/	
		
//		Criteria query = session.createCriteria(Employee.class);
//		query.addOrder(Order.desc("salary"));  
//		List<Employee> list = query.list();
//		for(Employee e: list)
//		{
//			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
//		}
//		tn.commit();

		

//		Criteria query = session.createCriteria(Employee.class);
//		query.add(Restrictions.between("salary",5000, 5500));
//		List<Employee> list = query.list();
//		for(Employee e: list)
//		{
//			System.out.println(e.getId()+" "+e.getName()+" "+e.getSalary());
//		}
//		tn.commit(); 
//	
		
		
//		Select Query
		
//
//     	NativeQuery query =session.createSQLQuery("select * from tbl_emp");
//		query.addEntity(Employee.class);
//		List<Employee> lst = query.list();
//		for(Employee  e: lst)		
//		{
//			System.out.println(e);
//		//System.out.println(lst);
//		}tn.commit();
//		
		
//		Delete Query
		
//		NativeQuery query =session.createSQLQuery("delete from tbl_emp where e_id=101");
//		query.addEntity(Employee.class);
//		int op = query.executeUpdate();
//	
//		if(op==1)
//		{
//		System.out.println("Data Deletion Successfully");
//		}
//		else
//		{
//			System.out.println("Data Deletion UnSuccessfully");
//		}
//		//System.out.println(lst);
//		tn.commit();
		
//		Update
		
//		NativeQuery query =session.createSQLQuery("update tbl_emp set e_name='Marshal' where e_id=102");
//		query.addEntity(Employee.class);
//		int op = query.executeUpdate();
//	
//		if(op==1)
//		{
//		System.out.println("Data Updation Successfully");
//		}
//		else
//		{
//			System.out.println("Data Updation UnSuccessfully");
//		}
		
	
		
		//Named Query
		
//		Query<Employee> quer = session.createNamedQuery("deleteEmployee");
//		quer.setParameter("StuId", 103);
//       int empRes=quer.executeUpdate(); 
//    
//       if(empRes ==1)
//       {
//    	   System.out.println("Deleted Successfully");
//       }
//       else
//       {
//    	   System.out.println("Deletion Unsuccessfully");
//       }
//	
		
		
		
		//Named Query
		
		Query<Employee> query = session.createNamedQuery("selectAllEmployee");
		List<Employee> lst = query.list();
		for(Employee e: lst)
		{
			System.out.println(e);
		}
		tn.commit();
		session.close();
		System.out.println("Object Saved");
		
	}

}
