package com.tms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DButil {

	public static Connection getDataBaseConnection() {
		Connection con = null;

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/TeacherDB", "root", "Pa55w0rd@2k23");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

	}
}
