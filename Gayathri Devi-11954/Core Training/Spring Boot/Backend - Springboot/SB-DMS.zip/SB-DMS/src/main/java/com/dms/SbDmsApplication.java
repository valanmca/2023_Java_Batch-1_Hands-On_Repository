package com.dms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbDmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbDmsApplication.class, args);
	}

}
