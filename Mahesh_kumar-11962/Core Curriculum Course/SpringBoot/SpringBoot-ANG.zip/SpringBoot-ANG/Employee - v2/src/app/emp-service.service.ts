import { Injectable } from '@angular/core';
import { Employee } from './model/Employee';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class EmpServiceService {


  private url: string = "http://localhost:1000";

  constructor(private http: HttpClient) { }


  InsertEmployee(employee: Employee) {
    this.http.post(this.url + "/PerformInsert", employee).subscribe();
    return "Record Inserted";
  }


  DeleteEmployee(employee: Employee) {
    this.http.delete(this.url + "/PerformDelete/" + employee.id).subscribe();
    return "Record Deleted";
  }

  UpdateEmployee(employee :Employee)
  {
    this.http.put(this.url+"/PerformUpdate",employee).subscribe();
    return "Record Updated";
  }

  getAllEmployeeDetails() {
    return this.http.get<Employee[]>(this.url + "/ViewAll");
  }
}
