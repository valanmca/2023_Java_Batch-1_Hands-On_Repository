package com.modeltms.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_tms")
public class ModelTeacher {

		@Id
		@Column(name = "id")
		private int id;
		@Column(name = "name")
		private String name;
		@Column(name = "gender")
		private String gender;
		@Column(name = "email")
		private String email;
		@Column(name = "qualification")
		private String qualification;
		@Column(name = "subject")
		private String subject;
		@Column(name = "phone")
		private String phone;
		public ModelTeacher() {
			super();
			// TODO Auto-generated constructor stub
		}
		public ModelTeacher(int id, String name, String gender, String email, String qualification, String subject,
				String phone) {
			super();
			this.id = id;
			this.name = name;
			this.gender = gender;
			this.email = email;
			this.qualification = qualification;
			this.subject = subject;
			this.phone = phone;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getQualification() {
			return qualification;
		}
		public void setQualification(String qualification) {
			this.qualification = qualification;
		}
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		@Override
		public String toString() {
			return "ModelTeacher [id=" + id + ", name=" + name + ", gender=" + gender + ", email=" + email
					+ ", qualification=" + qualification + ", subject=" + subject + ", phone=" + phone + "]";
		}
	
}