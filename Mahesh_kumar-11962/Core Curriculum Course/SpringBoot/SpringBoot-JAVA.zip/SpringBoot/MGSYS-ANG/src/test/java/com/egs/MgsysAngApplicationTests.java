package com.egs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgsysAngApplicationTests {

	@Test
	void contextLoads() {
	}

}
