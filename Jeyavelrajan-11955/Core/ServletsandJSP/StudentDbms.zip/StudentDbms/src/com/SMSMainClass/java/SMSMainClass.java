package com.SMSMainClass.java;

import java.util.List;
import java.util.Scanner;


import com.sms.bean.Student;
import com.sms.dao.StudentDAO;

public class SMSMainClass {
	static Scanner sc = new Scanner (System.in);
	public static int displaymenu(){
		System.out.println("<------->1. Insert 2.delete 3.Update 4.Find 5.Find All 6.Exit <------->");
        System.out.println("Enter your choice:");
        return sc.nextInt();
        
	}
	public static Student insertStudent() {
		System.out.println("To insert all the details Below ");
		System.out.println("Enter the StudentRollNo , StudentName , StudentEmail, StudentStandard , StudentLocation");
        return new Student(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.next());
	}
	
	public static int deleteStudent() {
		System.out.println("Enter the StudentRollNo to delete ");
		return sc.nextInt();
	}
	
	public static Student updateStudent() {
		System.out.println("To Update All the Details Below");
		System.out.println("Enter the StudentRollNo , StudentName , StudentEmail, StudentStandard , StudentLocation");
        return new Student(sc.nextInt(),sc.next(),sc.next(),sc.next(),sc.next());
	}
	public static int findStudent() {
		System.out.println("Enter the valid id to find the Student Details" );
		return sc.nextInt();
	}
	
	

	public static void main(String[] args) {
		StudentDAO dao = new StudentDAO();
		String msg ="";
		do {
			switch(displaymenu()) {
			case 1:
				if(dao.insertStudent(insertStudent())==1)
				System.out.println("Record inserted successfully");
				else
					System.out.println("Record is not inserted ");
				break;
			case 2:
				int StudentRollNo = deleteStudent();
				int n = dao.deleteStudent(StudentRollNo);
				if(n==1)
					System.out.println("Record Deleted Successfully ");
				else
					System.out.println("Record is Not Deleted ");
				break;
			case 3:
			  Student stu = updateStudent();
			  int n1 = dao.updateStudent(stu);
			  if(n1==1)
				  System.out.println("Record Updated Successfully ");
			  else
				  System.out.println("Record is Not Updated ");
			  break;
			case 4:
				int StudentRollNo1 = findStudent();
				Student bean = dao.findStudent(StudentRollNo1);
				if(bean != null) {
					bean.display();	
					}else {
						System.out.println("Record is  Not Found");
					}
				break;
			case 5:
				List<Student> list = dao.findAllStudent();
				for(Student e:list) {
					e.display();
				}
				break;
			  
			}
			System.out.println("Do you Want to continue [Yes|No]");
			msg=sc.next();
		}while(msg.equals("Yes"));
	}

}
