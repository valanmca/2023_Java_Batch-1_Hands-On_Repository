import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Laptop } from './model/Laptop';

@Injectable({
  providedIn: 'root'
})
export class LaptopService {
 private url: string="http://localhost:1111";
 
  constructor(private http :HttpClient) { }

  insertDetails(lap : Laptop) {
    this.http.post(this.url + "/PerformInsert", lap).subscribe();
    return "Record Inserted";
  }

  updateDetails(lap : Laptop) {
    this.http.put(this.url + "/PerformUpdate", lap).subscribe();
    return "Record Updated";
  } 

  deleteDetails(lap : Laptop) {
    this.http.delete(this.url + "/PerformDelete/"+lap.id).subscribe();
    return "Record Deleted";
  } 

  getAllDetails()
  {
    return this.http.get<Laptop[]>(this.url+"/ViewAll");
  }

}
