export class Laptop
{
    id!:number;
    brand!:string;
    model!:string;
    price!:number;
}