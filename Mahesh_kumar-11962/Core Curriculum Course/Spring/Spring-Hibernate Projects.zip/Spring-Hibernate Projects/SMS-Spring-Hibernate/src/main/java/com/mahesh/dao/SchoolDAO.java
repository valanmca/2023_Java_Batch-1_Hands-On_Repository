package com.mahesh.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.mahesh.bean.School;
import com.mahesh.util.DbUtill;


public class SchoolDAO {
	Session session;
	Transaction transaction;
	
	public void insertStudent(School bean)
	{
		session=DbUtill.getSession();
		transaction =session.beginTransaction();
		session.save(bean);
		transaction.commit();
		session.close();
		
	}
	
	public List<Integer> getIdlist()

	{	session=DbUtill.getSession();
		transaction =session.beginTransaction();
		Query query = session.createQuery("select sid from School");
		List<Integer> list = query.list();
		transaction.commit();
		session.close();
		return list;
		
	}
	public void deleteStudent(School bean)
	{
		session=DbUtill.getSession();
		transaction =session.beginTransaction();
		session.delete(bean);
		transaction.commit();
		session.close();
	}
	
	public void updateStudent(School bean)
	{
		session=DbUtill.getSession();
		transaction =session.beginTransaction();
		session.update(bean);
		transaction.commit();
		session.close();	
	}


	public School findStudent(School bean)
	{
		session=DbUtill.getSession();
		transaction =session.beginTransaction();
		School sc = session.get(School.class, bean.getSid());
		transaction.commit();
		session.close();
		return sc;
		
	}
	
	public List<School> viewAllStudent()
	{
		session=DbUtill.getSession();
		transaction =session.beginTransaction();
		Query query = session.createQuery("from School");
		List<School> StList = query.list();
		transaction.commit();
		session.close();
		return StList;
		
	}
}
