package com.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.ems.util.*;
import com.ems.bean.*;
import com.ems.bean.Employee;

public class EmployeeDAO {

	public int insertEmployee(Employee Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "insert into tbl_employee values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, Bean.getId());
			ps.setString(2, Bean.getName());
			ps.setInt(3, Bean.getDno());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int deleteEmployee(int id) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "delete from tbl_employee where employee_id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int updateEmployee(Employee Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "update tbl_employee set employee_name=?,employee_depid=? where employee_id=?";
			PreparedStatement ps = con.prepareStatement(sql);
		
			ps.setString(1, Bean.getName());
			ps.setInt(2, Bean.getDno());
			ps.setInt(3, Bean.getId());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public List<Employee> viewallEmployee() {
		List<Employee> list = new ArrayList<Employee>();

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_employee";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet re = ps.executeQuery();
			while (re.next()) {

				Employee bean = new Employee();
				bean.setId(re.getInt("employee_id"));
				bean.setName(re.getString("employee_name"));
				bean.setDno(re.getInt("employee_depid"));
				list.add(bean);

			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return list;

	}

	public Employee findEmloyee(int id) {
		Employee bean = null;

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_employee where employee_id =?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet re = ps.executeQuery();
			if (re.next()) {

				bean = new Employee();
				bean.setId(re.getInt("employee_id"));
				bean.setName(re.getString("employee_name"));
				bean.setDno(re.getInt("employee_depid"));

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return bean;
	}

	

}
