package com.gayathri;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gayathri.DAO.EmployeeDao;
import com.gayathri.bean.Employee;

@Controller
public class EMSController {

	@Autowired
	EmployeeDao dao;

	@RequestMapping("Head")
	public ModelAndView loadHead() {
		ModelAndView mv = new ModelAndView("Head");
		return mv;
	}

	@RequestMapping("Right")
	public ModelAndView loadRight() {
		ModelAndView mv = new ModelAndView("Right");
		return mv;
	}

	@RequestMapping("Linkes")
	public ModelAndView loadLinkes() {
		ModelAndView mv = new ModelAndView("Linkes");
		return mv;
	}

	@RequestMapping("InsertEmployee")
	public ModelAndView loadInsertEmployee() {
		ModelAndView mv = new ModelAndView("InsertEmployee");
		return mv;
	}

	@RequestMapping("PerformInsert")
	public ModelAndView performInsert(@ModelAttribute("bean") Employee bean) {
		dao.insertEmployee(bean);
		ModelAndView mv = new ModelAndView("InsertSuccess");
		mv.addObject("bean", bean);
		return mv;
	}

	@RequestMapping("UpdateEmployee")
	public ModelAndView loadUpdateEmployee() {
		ModelAndView mv = new ModelAndView("UpdateEmployee");
		return mv;
	}

	@RequestMapping("PerformUpdate")
	public ModelAndView performUpdate(@ModelAttribute("bean") Employee bean) {
		dao.updateEmployee(bean);
		ModelAndView mv = new ModelAndView("UpdateSuccess");
		mv.addObject("bean", bean);
		return mv;
	}

	@RequestMapping("DeleteEmployee")
	public ModelAndView loadDeleteEmployee() {
		List<Integer> list = dao.getIdList();
		ModelAndView mv = new ModelAndView("DeleteEmployee");
		mv.addObject("idList", list);
		return mv;
	}

	@RequestMapping("PerformDelete")
	public ModelAndView performDelete(@ModelAttribute("bean") Employee bean) {
		dao.deleteEmployee(bean);
		ModelAndView mv = new ModelAndView("DeleteSuccess");
		mv.addObject("bean", bean);
		return mv;
	}

	@RequestMapping("SearchEmployee")
	public ModelAndView loadSearchEmployee() {
		List<Integer> list = dao.getIdList();
		ModelAndView mv = new ModelAndView("SearchEmployee");
		mv.addObject("idList", list);
		return mv;
	}

	@RequestMapping("PerformSearch")
	public ModelAndView performSearch(@ModelAttribute("bean") Employee bean) {
		Employee emp = dao.searchEmployee(bean);
		ModelAndView mv = new ModelAndView("SearchSuccess");
		mv.addObject("emp", emp);
		return mv;
	}

	@RequestMapping("performView")
	public ModelAndView loadViewAll() {
		List<Employee> empList = dao.performView();
		ModelAndView mv = new ModelAndView("ViewAll");
		mv.addObject("idList", empList);
		return mv;
	}
}
