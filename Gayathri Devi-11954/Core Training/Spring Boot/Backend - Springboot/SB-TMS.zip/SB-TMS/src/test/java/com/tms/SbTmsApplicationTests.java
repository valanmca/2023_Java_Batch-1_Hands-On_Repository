package com.tms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbTmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
