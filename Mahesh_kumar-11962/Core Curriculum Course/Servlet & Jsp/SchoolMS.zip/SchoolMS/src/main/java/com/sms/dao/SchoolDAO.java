package com.sms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.sms.bean.School;
import com.sms.util.DBUtil;


public class SchoolDAO {

	public int insertStudent(School Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "insert into tbl_student values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, Bean.getId());
			ps.setString(2, Bean.getName());
			ps.setInt(3, Bean.getDno());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int deleteStudent(int id) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "delete from  tbl_student  where studentid = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int updateStudent(School Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "update tbl_student set studentname=?,studentdepno=? where studentid=?";
			PreparedStatement ps = con.prepareStatement(sql);
		
			ps.setString(1, Bean.getName());
			ps.setInt(2, Bean.getDno());
			ps.setInt(3, Bean.getId());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public List<School> viewallStudent() {
		List<School> list = new ArrayList<School>();

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_student";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet re = ps.executeQuery();
			while (re.next()) {

				School bean = new School();
				bean.setId(re.getInt("studentid"));
				bean.setName(re.getString("studentname"));
				bean.setDno(re.getInt("studentdepno"));
				list.add(bean);

			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return list;

	}

	public School findStudent(int id) {
		School bean = null;

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_student where studentid =?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet re = ps.executeQuery();
			if (re.next()) {

				bean = new School();
				bean.setId(re.getInt("studentid"));
				bean.setName(re.getString("studentname"));
				bean.setDno(re.getInt("studentdepno"));

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return bean;
	}

	

}
