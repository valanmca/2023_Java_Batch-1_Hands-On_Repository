package com.VMS.util;

import java.sql.*;

public class DBConnect {

	public static Connection getDBconnection() {

		Connection connect = null;

		try {
			connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/VehicleInformation", "root", "Pa55w0rd@2k23");
		} catch (Exception e) {

			System.out.println("Exception occured during Connection");
		}
		return connect;

	}
}
