package com.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tms.bean.Teacher;
import com.tms.util.DButil;

public class TeacherDAO {

	public static int insertDetails(Teacher Bean) {
		int n = 0;
		try {

			Connection con = DButil.getDataBaseConnection();
			String insertquery = "insert into tbl_teacher values(?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(insertquery);

			ps.setInt(1, Bean.getTeacherId());
			ps.setString(2, Bean.getTeacherName());
			ps.setString(3, Bean.getTeacherEmail());
			ps.setString(4, Bean.getTeacherQualification());
			ps.setString(5, Bean.getTeacherLocation());

			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception happened during connection");
		}
		return n;
	}

	public static int deleteDetails(int id) {
		int n = 0;
		try {

			Connection con = DButil.getDataBaseConnection();
			String deletequery = "delete from tbl_teacher where tid=?";
			PreparedStatement ps = con.prepareStatement(deletequery);
			ps.setInt(1, id);
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception happened during connection");
		}
		return n;
	}

	public static int updateDetails(Teacher Bean) {
		int n = 0;
		try {

			Connection con = DButil.getDataBaseConnection();
			String insertquery = "update tbl_teacher set tname=?,temail=?,tdegree=?,tlocation=? where tid =?";
			PreparedStatement ps = con.prepareStatement(insertquery);

			ps.setString(1, Bean.getTeacherName());
			ps.setString(2, Bean.getTeacherEmail());
			ps.setString(3, Bean.getTeacherQualification());
			ps.setString(4, Bean.getTeacherLocation());
			ps.setInt(5, Bean.getTeacherId());
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("Exception happened during connection");
		}
		return n;
	}

	public static Teacher findDetails(int id) {

		Teacher bean = null;
		try {

			Connection con = DButil.getDataBaseConnection();
			String searchquery = "select * from tbl_teacher where tid=?";
			PreparedStatement ps = con.prepareStatement(searchquery);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				bean = new Teacher();
				bean.setTeacherId(rs.getInt("tid"));
				bean.setTeacherName(rs.getString("tname"));
				bean.setTeacherEmail(rs.getString("temail"));
				bean.setTeacherQualification(rs.getString("tdegree"));
				bean.setTeacherLocation(rs.getString("tlocation"));
			}

		} catch (Exception e) {
			System.out.println("Exception happened during connection");
		}
		return bean;
	}

	public static List<Teacher> findAllDetails() {

		List<Teacher> lst = new ArrayList<Teacher>();
		try {

			Connection con = DButil.getDataBaseConnection();
			String viewquery = "select * from tbl_teacher";
			PreparedStatement ps = con.prepareStatement(viewquery);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				Teacher bean = new Teacher();
				bean.setTeacherId(rs.getInt("tid"));
				bean.setTeacherName(rs.getString("tname"));
				bean.setTeacherEmail(rs.getString("temail"));
				bean.setTeacherQualification(rs.getString("tdegree"));
				bean.setTeacherLocation(rs.getString("tlocation"));
				lst.add(bean);
			}
		} catch (Exception e) {
			System.out.println("Exception happened during connection");
		}
		return lst;

	}
}
