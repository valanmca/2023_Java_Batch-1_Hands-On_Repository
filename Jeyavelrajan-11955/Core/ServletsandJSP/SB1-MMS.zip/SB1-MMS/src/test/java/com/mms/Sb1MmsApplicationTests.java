package com.mms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb1MmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
