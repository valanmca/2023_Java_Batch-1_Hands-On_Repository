import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Doctor } from './model/doctor';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private url:string = 'http://localhost:3004/posts'

  constructor(private  http:HttpClient) { }

  insertDetails(doctor:Doctor) {
    this.http.post(this.url, doctor).subscribe();
    return "Record Inserted";
  }

  updateDetails(doctor:Doctor) {
    this.http.put(this.url + "/" + doctor.id, doctor).subscribe();
    return "Record Updated";
  }
  deleteDetails(doctor:Doctor) {
    this.http.delete(this.url + "/" + doctor.id).subscribe();
    return "Record Deleted";
  }

  getAllDetails(){
    return this.http.get<Doctor[]>(this.url)
   }
}
