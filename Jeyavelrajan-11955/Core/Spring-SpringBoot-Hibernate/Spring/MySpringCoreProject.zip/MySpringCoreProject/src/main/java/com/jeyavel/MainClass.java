package com.jeyavel;

import javax.xml.stream.XMLEventFactory;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainClass {
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
                        
		//Using List
		                //Object 
//		Employee bean = (Employee) context.getBean("employee");// Injection
//		System.out.println(bean);
		
		
		
		
		//Using Map
//		Employee bean1 = (Employee) context.getBean("EmpAddress1");
//		System.out.println(bean1);
		
		
		
		//using Set
		
		Employee bean2 = (Employee) context.getBean("EmpSetExperience");
		System.out.println(bean2);

	}

}
