package com.modeltms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbModelTmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
