package com.vems.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

	public static Connection getDBconnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/VMSDataBase", "root", "Pa55w0rd@2k23");
			
		} catch (Exception e) {

			System.out.println(e);
		}
		return con;
	}

}
