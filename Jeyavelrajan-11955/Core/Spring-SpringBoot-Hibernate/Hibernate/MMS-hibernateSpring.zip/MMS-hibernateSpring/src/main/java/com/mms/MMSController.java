package com.mms;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mms.bean.Movie;
import com.mms.dao.Moviedao;

@Controller
public class MMSController {
	
	@Autowired
	Moviedao dao;
	
	@RequestMapping("MovHead")
	public ModelAndView loadMovHead() {
	   ModelAndView mv = new ModelAndView ();
	   mv.setViewName("MovHead");
	return mv;
	   
	}
	
	@RequestMapping("insertMovie")
	public ModelAndView loadinsertMovie() {
		ModelAndView mv= new ModelAndView();
		mv.setViewName("insertMovie");
		return mv;
	}
	
	@RequestMapping("PerformInsert")
	public ModelAndView performInsertMovie(@ModelAttribute("bean") Movie bean) {
		
		ModelAndView mv = new ModelAndView();
	    try {
	    	  dao.insertMovie(bean);
	    	  mv.setViewName("insertMovieSuccess");

	    }catch(Exception e){
	    	
	    	mv.setViewName("insertMovieFail");
	    }
	   return mv;
}
	
	@RequestMapping("deleteMovie")
	public ModelAndView loadDeleteDoctor() 
	{
		List<Integer> list=dao.getIdList();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("deleteMovie");
		mv.addObject("idList",list);
		return mv;
	}
	
	
	@RequestMapping("PerformDelete")
	public ModelAndView performDeleteDoctor(@ModelAttribute("bean") Movie bean) {
	            
	    {
	        dao.deleteMovie(bean);
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("deleteMovieSuccess");
	        return mv;
	    }
	}
	
	
	@RequestMapping("updateMovie")
	public ModelAndView loadupdateMovie() {
		ModelAndView mv= new ModelAndView();
		mv.setViewName("updateMovie");
		return mv;
	}
	
	@RequestMapping("PerformUpdate")
	public ModelAndView performupdateMovie(@ModelAttribute("bean") Movie bean) {
		
		ModelAndView mv = new ModelAndView();
	    try {
	    	  dao.updateMovie(bean);
	    	  mv.setViewName("updateMovieSuccess");

	    }catch(Exception e){
	    	
	    	mv.setViewName("updateMovieFail");
	    }
	   return mv;
}
	
	@RequestMapping("findMovie")
	public ModelAndView loadFindDoctor() 
	{
		List<Integer> list=dao.getIdList();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("findMovie");
		mv.addObject("idList2",list);
		return mv;
	
	
	}
	
	 @RequestMapping("PerformFind")
	    public ModelAndView findMovie(@ModelAttribute("bean") Movie bean)
	    {
	        Movie value=dao.findMovie(bean);
	        
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("findMovieSuccess");
	        mv.addObject("mov",value);
	        return mv;
	    }
	 
	 @RequestMapping("findAllMovie")
	    public ModelAndView FindAllDoctor()
	    {
	        List<Integer> list=dao.getAllList();
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("findAllMovie");
	        mv.addObject("idList1",list);
	        return mv;
	    }
	
	
	
	
	
	
}
	
	
	
		
	

