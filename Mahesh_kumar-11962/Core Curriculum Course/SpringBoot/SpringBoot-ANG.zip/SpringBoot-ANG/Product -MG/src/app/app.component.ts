import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Product } from './model/Product';
import { ProductService } from './product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'PMS-SPBT';

  ProForm: FormGroup;
  product: Product;
  result: string = "";
  productList: Product[] = [];

  constructor(private pro : ProductService)
  {
    this.ProForm=new FormGroup({
      pid: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
      pname: new FormControl('', [Validators.required, Validators.pattern('[a-zA-Z -]+')]),
      pcount: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
      pprice: new FormControl('', [Validators.required, Validators.pattern('[0-9]+')]),
    })
    this.product=new Product();
    this.getAllproducts();
  }
  InsertProduct(data: any) {
    this.product.pid = data.pid;
    this.product.pname = data.pname;
    this.product.pcount = data.pcount;
    this.product.pprice = data.pprice;
    this.result = this.pro.InsertProduct(this.product);
  
    alert(data.pid+" "+data.pname+" "+data.pcount+" "+data.pprice+" Data Inserted")
    this.getAllproducts();
      }
  
  Deleteproduct(data: any) {
    alert(data.pid+" Deleted ");
    this.product.pid = data.pid;
    this.result = this.pro.DeleteProduct(this.product);
    this.getAllproducts();
  
  }
  
  Updateproduct(data: any) {
    alert("UpdatedData" + data.pid + " " + data.pname + " " +data.pcount+" "+ data.pprice);
    this.product.pid= data.pid;
    this.product.pname = data.pname;
    this.product.pcount = data.pcount;
    this.product.pprice = data.pprice;
    this.result = this.pro.UpdateProduct(this.product);
    this.getAllproducts();
   
  
   }
  
  
  getAllproducts() {

    this.pro.getAllProductDetails().subscribe(productitem=>this.productList =productitem);
   
  } 

  


}
