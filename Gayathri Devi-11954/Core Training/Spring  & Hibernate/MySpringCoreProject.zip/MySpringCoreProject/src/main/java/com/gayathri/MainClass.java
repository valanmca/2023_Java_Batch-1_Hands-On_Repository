package com.gayathri;

import org.springframework.beans.factory.BeanFactory;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainClass {

	public static void main(String[] args) {
		// Tightly coupled Application
		// Employee emp = new Employee(1,"Gayathri",100000);
		// emp.display();

		// reading data from ? and initializing ?
		//ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Resource resource = new ClassPathResource("Beans.xml");
		BeanFactory factory = new XmlBeanFactory(resource);

		//Employee bean1 = (Employee) factory.getBean("constructorInjectionEmployee");
		//System.out.println(bean1);
	/*	Address ad1 = (Address) context.getBean("address1");
		System.out.println(ad1);
	*/	//Employee bean2 = (Employee) factory.getBean("employee1");
		//System.out.println(bean2);
/*		Address ad2 = (Address) context.getBean("address1");
		System.out.println(ad2);
*/	
		Employee bean3 = (Employee) factory.getBean("constructorInjectionUsingMap");
		System.out.println(bean3);
	}

}
