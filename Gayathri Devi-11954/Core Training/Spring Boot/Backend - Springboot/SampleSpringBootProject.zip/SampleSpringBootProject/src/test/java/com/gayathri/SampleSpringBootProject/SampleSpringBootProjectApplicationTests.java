package com.gayathri.SampleSpringBootProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
