package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Factorial
 */
@WebServlet("/Factorial")
public class Factorial extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<center>");
		
		String input = request.getParameter("UserInput");
		int num = Integer.parseInt(input);
		out.print("<table border = 3px width =60%>");
		out.print("<tr border = 3px><th>Number</th><th>Factorial</th></tr>");

		int fact = 1;
		int val = 0;
		for (int n = 1; n <= num; n++) {
			fact = fact * n;
			val++;

		}
		out.println("<tr border = 3px><th>" + val + "</th><th>" + fact + "</th></tr>");
		out.print("</table>");
		out.print("<br><h3>Factorial value :"+fact+"</h3>");
		out.print("</center>");
		out.print("</html>");

	}

}
