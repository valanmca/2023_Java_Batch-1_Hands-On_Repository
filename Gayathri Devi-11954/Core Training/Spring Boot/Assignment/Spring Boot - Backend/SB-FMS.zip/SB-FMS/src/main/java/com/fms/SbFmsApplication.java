package com.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbFmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbFmsApplication.class, args);
	}

}
