package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ems.bean.Employee;
import com.ems.dao.EmployeeDAO;

@RestController
@CrossOrigin("http://localhost:4200/")
public class EMSController {

	
	@Autowired
	EmployeeDAO dao;
	
	@PostMapping("/PerformInsert")
	public void performInsert(@RequestBody Employee emp)
	{
		dao.save(emp);
	}
	
	@PostMapping("/PerformUpdate")
	public void performUpdate(@RequestBody Employee emp)
	{
		dao.save(emp);
	}
}
