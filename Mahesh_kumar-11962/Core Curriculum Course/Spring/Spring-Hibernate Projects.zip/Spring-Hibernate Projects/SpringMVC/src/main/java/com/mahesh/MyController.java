package com.mahesh;

import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mahesh.bean.Addition;
import com.mahesh.bean.Employee;

@Controller
public class MyController {
	@RequestMapping("Welcome")
	public ModelAndView sayWelcome() {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("Welcome");
		return mv;
	}

	@RequestMapping("Hello")
	public ModelAndView sayHello() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Hello");
		return mv;
	}

	@RequestMapping("SUM")
	public ModelAndView sayAdd() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("SUM");
		return mv;
	}
	
	@RequestMapping("Addition")
	public ModelAndView performAddTwoVal(@ModelAttribute("addition") Addition addition)
	{	ModelAndView mv = new ModelAndView("Addresult");
	//	int sum = addition.getN1()+addition.getN2();
		mv.addObject("bean",addition);
		return mv;
	}
//	
//	
//	@RequestMapping("SUM")
//	public ModelAndView sumTwoValue(HttpServletRequest request)
//	{		
//	int result=0;
//	int num1 = Integer.parseInt(request.getParameter("txt1"));
//	int num2 = Integer.parseInt(request.getParameter("txt2"));
//
//	result= num1+num2;
//	String output =Integer.toString(result);
//	return new ModelAndView("Addresult","output",output);
//	}		

	@RequestMapping("AddEmployeeInfo")
	public ModelAndView sayAddEmployee() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addEmployeeDetails");
		return mv;
	}
	
	@RequestMapping("AddEmp")
	public ModelAndView performAddEmployeeInfo(@ModelAttribute("employee") Employee emp)
	{	ModelAndView mv = new ModelAndView("AddEmpResult");
		mv.addObject("bean",emp);
		return mv;
	}
}
