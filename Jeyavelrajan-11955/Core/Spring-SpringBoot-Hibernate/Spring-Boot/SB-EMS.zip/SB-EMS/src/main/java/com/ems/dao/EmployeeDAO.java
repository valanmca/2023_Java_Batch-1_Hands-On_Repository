package com.ems.dao;

//import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ems.bean.Employee;


public interface EmployeeDAO extends CrudRepository<Employee,Integer>{
	
//	Employee findByName(String Name);
//    void deleteByName(String Name);
//    Employee findBySalary(int Salary);
//    
//    @Query("select * from tbl_employee where Salary > 2000")
//    List<Employee> getAllEmployeeByUsingSalary();
	
	

}
