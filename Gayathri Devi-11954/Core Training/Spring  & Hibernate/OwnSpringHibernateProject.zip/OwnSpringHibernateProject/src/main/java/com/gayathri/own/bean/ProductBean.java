package com.gayathri.own.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_pms")
public class ProductBean {
	
	@Id
	
	@Column(name="p_id")
	private int pId;
	
	@Column(name="p_name")
	private String pName;
	
	@Column(name="p_quantity")
	private int pQuantity;
	
	@Column(name="p_price")
	private float pPrice;
	
	public ProductBean() {
		super();
	}
	public ProductBean(int pId, String pName, int pQuantity, float pPrice) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pQuantity = pQuantity;
		this.pPrice = pPrice;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpQuantity() {
		return pQuantity;
	}
	public void setpQuantity(int pQuantity) {
		this.pQuantity = pQuantity;
	}
	public float getpPrice() {
		return pPrice;
	}
	public void setpPrice(float pPrice) {
		this.pPrice = pPrice;
	}
	
	@Override
	public String toString() {
		return "ProductBean [pId=" + pId + ", pName=" + pName + ", pQuantity=" + pQuantity + ", pPrice=" + pPrice + "]";
	}
}
