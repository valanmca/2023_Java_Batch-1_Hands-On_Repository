package com.gayathri;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

public class MainClass {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml"); //loading cfg file for database connection and go to hbm file for mapping
		
		SessionFactory factory = cfg.buildSessionFactory();		
		Session session = factory.openSession();		
		Transaction tn = session.beginTransaction();
		
		Query<Employee> query=  session.createNamedQuery("SelectAllEmployee");
		List<Employee> list = query.list();
		for(Employee e : list)
			System.out.println(e);
		
		
		tn.commit();
		
		session.close();
		
		//System.out.println("Object Saved check your database");

	}

}
