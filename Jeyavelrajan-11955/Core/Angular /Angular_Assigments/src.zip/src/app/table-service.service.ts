import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TableServiceService {
 
// mtable(num1:number,num2:number){
//   return num1*num2;
getTable(a:number,b:number):number{
  return a*b;
  
   }

}

 






