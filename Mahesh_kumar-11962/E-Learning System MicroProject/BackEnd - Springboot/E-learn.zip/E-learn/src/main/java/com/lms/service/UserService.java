package com.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.bean.User;
import com.lms.repo.UserRepository;

import jakarta.servlet.http.HttpSession;




@Service
public class UserService {

	@Autowired
	UserRepository repo;
	User user;


	public boolean registerUser(User user) {
		user.setUserType("RegisteredUser");
		repo.save(user);
		return true;
	}
	
	public boolean loginUser(User user) {
		User mail = repo.findByUserMailId(user.getUserMailId());
		User pwd = repo.findByUserPassword(user.getUserPassword());
		if (mail != null && pwd != null) {
			String check = mail.getUserPassword();
			String verify = mail.getUserPassword();
			if (check.equals(verify)) {
				return true;
			}
		}
		return false;
	}

	
/*
	public void loginUser(HttpSession session, String username) {
		session.setAttribute(SESSION_AUTH_KEY, username);
	}

	public void logoutUser(HttpSession session) {
		session.removeAttribute(SESSION_AUTH_KEY);
	}

	public String getCurrentUser(HttpSession session) {
		try {
			return session.getAttribute(SESSION_AUTH_KEY).toString();
		} catch (Exception e) {
			return null;
		}
	}
*/
	
	
}
