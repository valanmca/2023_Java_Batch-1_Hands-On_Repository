package com.mahesh;

import org.springframework.stereotype.Controller;

@Controller
public class EmsController {

	
}
