package com.hms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.bean.Doctor;
import com.hms.dao.DoctorDAO;


@WebServlet("/HMSController")
public class HMSController extends HttpServlet {

	DoctorDAO dao = new DoctorDAO();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
		 String requestForm = request.getParameter("ems_button");
		 
		 if(requestForm.equals("Insert Doctor")) {
			 int doctorId= Integer.parseInt(request.getParameter("DocId"));
			 String doctorName = request.getParameter("DocName");
			 String doctorSpecialization = request.getParameter("DocSpecialization");
			 int doctorSalary = Integer.parseInt(request.getParameter("DocSalary"));
			 
			 Doctor bean = new Doctor(doctorId,doctorName,doctorSpecialization,doctorSalary);
			 int m = dao.insertDoctor(bean);
			 
			 if(m == 1) {
				 response.sendRedirect("insertDoctorSuccess.jsp");
			 }else {
				 response.sendRedirect("insertDoctorFail.jsp");
			 }
			 
		 }
				
		
	}

}
