package com.jeyavel;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;


public class MainClass {
	
	public static void main(String[] args) {
		
			Configuration cfg=new Configuration();
			cfg.configure("hibernate.cfg.xml");
			                       //by using configuration object we build session factory 
			SessionFactory factory=cfg.buildSessionFactory();
			Session session=factory.openSession();
			Transaction tn=session.beginTransaction();
//			Employee emp=new Employee ();
//			emp.setId(11955);
//			emp.setName("jeyavel");
//			emp.setSalary(50000);
//			emp.setDno(12);
//			session.save(emp);//Insert
			
			
	// Hql - Hibernate always depend on Object
			
			//Select * and select particular id 
				
//			String hql = "from Employee";
//			String hql = " from employee where id=11955";
//            Query<Employee> query = session.createQuery(hql);
//            List<Employee> list = query.list();
//            System.out.println(list);
            
//            for(Employee e: list){
//                System.out.println(e.getId()+""+e.getName()+""+e.getSalary()+""+e.getDno());
//            }
			
			//Dynamic HQL querries 
//			String hql = "from Employee where id=:t";
//			Query<Employee> query = session.createQuery(hql);
//			query.setParameter("t", 11955);
//			List<Employee> list = query.list();
//			
//			for(Employee e: list){
//				System.out.println(e.getId()+""+e.getName()+""+e.getSalary()+""+e.getDno());
//			}
			
			
			
	//    String hql = "update Employee set Salary=:s where Id=:i";
			
//			String hql = "delete Employee where Id=:i";
//            Query<Employee> query = session.createQuery(hql);
			//   query.setParameter("s", 3000);
//            query.setParameter("i", 11955);
//            int n= query.executeUpdate();
//                                 
//            
//            if(n==1){
//                System.out.println("Record Deleted");
//            }else {
//                System.out.println("Record is Not Deleted");
//            }
//            
//            tn.commit();         // If we want to undo we can use RollBack
//            session.close();
//            System.out.println("Object Saved");
//            }
			
			
			
			//Criteria query 
			
//			Criteria query = session.createCriteria(Employee.class);
//			query.add(Restrictions.eq("id",11955));
//			query.add(Restrictions.gt("Salary", 40000));
//			query.addOrder(Order.asc("id"));
//			List<Employee> list = query.list();
//			for(Employee e: list) {
//				System.out.println(e);
//			}
//			
//	          tn.commit();      
//            session.close();
//            System.out.println("Object Saved");
//			
//	}
	
//---------------------------------------------------------------------------------------------------
			
			
			
			//Native Sql querry
            //Find All
//			NativeQuery<Employee>query = session.createSQLQuery("select * from tbl_employee");
//			query.addEntity(Employee.class);
//			List<Employee>list = query.list();
//			for(Employee e:list) {
//				System.out.println(e.getId()+""+e.getName()+""+e.getSalary()+""+e.getDno());
//			}
//			System.out.println(list);
//			  tn.commit();      
//            session.close();
//            System.out.println("Object Saved");
//			
//	
//	

	//DELETE
//	NativeQuery query = session.createSQLQuery("delete from tbl_employee where Id = 11959");
//	query.addEntity(Employee.class);
//	int id = query.executeUpdate();
//if(id==1) {
//	System.out.println("Record deleted");
//}else {
//	System.out.println("Record is not deleted ");
//}
//	  tn.commit();      
//    session.close();
//    System.out.println("Object Saved");
//	
//	}
			
			//Find 
//			NativeQuery query = session.createSQLQuery("select * from tbl_employee where Id = 11955");
//			query.addEntity(Employee.class);
//			List <Employee> list = query.getResultList();
//			System.out.println(list);
//
//			tn.commit();      
//		    session.close();
//		    System.out.println("Object Saved");
//			
//			}
			
//			NativeQuery query = session.createSQLQuery("update tbl_employee set Name='jeyavel_raj' where id=11955");
//			query.addEntity(Employee.class);
//			int id = query.executeUpdate();
//			System.out.println(id);
//
//			tn.commit();      
//		    session.close();
//		    System.out.println("Object Saved");
//			
//			}
			
			
			
			
			
			
            // Named Queries
			Query<Employee> query = session.createNamedQuery("SelectEmployee");
			List<Employee> list=query.list();
	        System.out.println(list);
			tn.commit();      
		    session.close();
	
			
	}
}


