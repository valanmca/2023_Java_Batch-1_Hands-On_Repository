import { Component } from '@angular/core';
import { TableServiceService } from '../table-service.service';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {
//   digitsArray:number[];
//   resultNumber:number;

// constructor(private table:TableServiceService){
// this.digitsArray=[1,2,3,4,5,6,7,8,9,10];
// this.resultNumber=0;

// }
// getMultiplicationTable(digitsArray:number,resultNumber:number):number
// {
// return this.resultNumber=this.table.mtable(digitsArray,resultNumber);
// }
a:number[];
a1:number;

constructor(private tab:TableServiceService){
 this.a=[1,2,3,4,5,6,7,8,9,10];
 this.a1=1;


}
 c:number=0;
 getfactorial(a:number,b:number):number{
  return this.c= this.tab.getTable(a,b);
 }
}
