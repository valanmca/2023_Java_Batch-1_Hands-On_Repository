package com.fms.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_flight")
public class Flight {

	@Id
	@Column(name = "f_no")
	private String fno;
	@Column(name = "f_type")
	private String ftype;
	@Column(name = "f_source")
	private String fsource;
	@Column(name = "f_destination")
	private String fdestination;
	@Column(name = "f_esc")
	private int fesc;
	@Column(name = "f_bsc")
	private int fbsc;
	@Column(name = "f_efare")
	private int fefare;
	@Column(name = "f_bfare")
	private int fbfare;

	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Flight(String fno, String ftype, String fsource, String fdestination, int fesc, int fbsc, int fefare,
			int fbfare) {
		super();
		this.fno = fno;
		this.ftype = ftype;
		this.fsource = fsource;
		this.fdestination = fdestination;
		this.fesc = fesc;
		this.fbsc = fbsc;
		this.fefare = fefare;
		this.fbfare = fbfare;
	}

	public String getFno() {
		return fno;
	}

	public void setFno(String fno) {
		this.fno = fno;
	}

	public String getFtype() {
		return ftype;
	}

	public void setFtype(String ftype) {
		this.ftype = ftype;
	}

	public String getFsource() {
		return fsource;
	}

	public void setFsource(String fsource) {
		this.fsource = fsource;
	}

	public String getFdestination() {
		return fdestination;
	}

	public void setFdestination(String fdestination) {
		this.fdestination = fdestination;
	}

	public int getFesc() {
		return fesc;
	}

	public void setFesc(int fesc) {
		this.fesc = fesc;
	}

	public int getFbsc() {
		return fbsc;
	}

	public void setFbsc(int fbsc) {
		this.fbsc = fbsc;
	}

	public int getFefare() {
		return fefare;
	}

	public void setFefare(int fefare) {
		this.fefare = fefare;
	}

	public int getFbfare() {
		return fbfare;
	}

	public void setFbfare(int fbfare) {
		this.fbfare = fbfare;
	}

	@Override
	public String toString() {
		return "Flight [fno=" + fno + ", ftype=" + ftype + ", fsource=" + fsource + ", fdestination=" + fdestination
				+ ", fesc=" + fesc + ", fbsc=" + fbsc + ", fefare=" + fefare + ", fbfare=" + fbfare + "]";
	}

}
