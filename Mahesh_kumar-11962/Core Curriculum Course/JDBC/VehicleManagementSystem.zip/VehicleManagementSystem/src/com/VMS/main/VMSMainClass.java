package com.VMS.main;

import java.util.List;
import java.util.Scanner;

import com.VMS.bean.Vehicle;
import com.VMS.dao.VmsDao;

public class VMSMainClass {

	static Scanner sc = new Scanner(System.in);

	public static int menu() {
		System.out.println(
				"1.Insert Details 2.Delte Details 3.Update Details 4.Find Details 5.View All Details 6.Exit->");
		System.out.print("Select your choice : ");
		return sc.nextInt();

	}

	public static Vehicle insertBikeDetails() {
		System.out.println("Enter Bike no , Bike Brand, Bike Model & Bike Price :");
		return new Vehicle(sc.nextInt(), sc.next(), sc.next(), sc.nextDouble());

	}

	public static int deleteBikeDetails() {
		System.out.println("Enter Bike no you want to delete : ");

		return sc.nextInt();
	}
	
	

	public static void main(String[] args) {
		VmsDao Dao = new VmsDao();

		String msg = "";
		do {
			switch (menu()) {
			case 1:

				if (Dao.insertBikeDetails(insertBikeDetails()) == 1) {
					System.out.println("Data Inserted Successfully");

				} else {
					System.out.println("Data Inserted Unsuccessfully");
				}

				break;

			case 2:
				if(Dao.deleteBikeDetails(deleteBikeDetails())==1)
				{
					System.out.println("Data Deleted Successfully");
					
				}
				else
				{
					System.out.println("Data Deleted Unsuccessfully");
					
				}

				break;
			case 3:
				
				List <Vehicle> lst= Dao.viewallBikedetails();
				
				for(Vehicle obj : lst)
				{
					obj.display();
				}
				break;

			default:
				break;

			}
			System.out.println("Do you want continue [Yes | No] :");
			msg = sc.next();
		} while (msg.equalsIgnoreCase("yes"));
	}

}
