package com.ems.bean;

public class Employee {

	private int id;
	private String name;
	private int dno;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, int dno) {
		super();
		this.id = id;
		this.name = name;
		this.dno = dno;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDno() {
		return dno;
	}

	public void setDno(int dno) {
		this.dno = dno;
	}

	public void display() {

		System.out.println("Employee id : " + id);
		System.out.println("Employee Name : " + name);
		System.out.println("Employee Deptno : " + dno);
		System.out.println("\t--*--");

	}

}
