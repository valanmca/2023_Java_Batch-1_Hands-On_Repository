export class Doctor{
    id!:any;
    name!:string;
    age!:number;
    email!:string;
    specialization!:string;
    contactnumber!:number;
    location!:string;

}