package com.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.lms.bean.User;
import com.lms.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService service;

	@PostMapping("/register")
	public String performRegister(@RequestBody User user) {

		service.registerUser(user);
		return "Register Success";
	}

	@GetMapping("/login")
	public String performLogin(@ModelAttribute User user) {

		boolean result = service.loginUser(user);
		if (result == true) {
			return "Login Success";
		} else {
			return "Login Fail";
		}

		
	}

}
