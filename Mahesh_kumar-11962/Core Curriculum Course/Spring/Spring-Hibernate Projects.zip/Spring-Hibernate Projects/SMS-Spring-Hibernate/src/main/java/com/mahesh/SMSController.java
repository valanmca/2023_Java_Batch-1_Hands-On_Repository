package com.mahesh;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mahesh.bean.School;
import com.mahesh.dao.SchoolDAO;

@Controller
public class SMSController {

	@Autowired
	SchoolDAO dao;

	@RequestMapping("options")
	public ModelAndView locateOption() {
		ModelAndView mv = new ModelAndView("options");
		return mv;
	}

	@RequestMapping("windows")
	public ModelAndView locateWindow() {
		ModelAndView mv = new ModelAndView("windows");
		return mv;
	}

	@RequestMapping("InsertPage")
	public ModelAndView locateInsert() {
		ModelAndView mv = new ModelAndView("InsertPage");
		return mv;
	}

	@RequestMapping("performInsert")
	public ModelAndView performInsert(@ModelAttribute("bean") School bean) {
		ModelAndView mv = new ModelAndView();
		try {
			dao.insertStudent(bean);
			mv.setViewName("InsertSuccess");
		} catch (Exception e) {
			mv.setViewName("InsertFail");
		}
		return mv;
	}

	@RequestMapping("DeletePage")
	public ModelAndView locateDelete() {
		List<Integer> list = dao.getIdlist();
		ModelAndView mv = new ModelAndView("DeletePage");
		mv.addObject("idList", list);
		return mv;
	}

	@RequestMapping("performDelete")
	public ModelAndView performDelete(@ModelAttribute("bean") School bean) {
		
		ModelAndView mv = new ModelAndView();
		try {
			dao.deleteStudent(bean);
			mv.setViewName("DeleteSuccess");
		}
		catch(Exception e)
		{
			mv.setViewName("DeleteFail");
		}
		//mv.addObject("value", bean);
		return mv;
	}

	@RequestMapping("UpdatePage")
	public ModelAndView locateUpdate() {
		ModelAndView mv = new ModelAndView("UpdatePage");
		return mv;
	}

	@RequestMapping("performUpdate")
	public ModelAndView performUpdate(@ModelAttribute("bean") School bean) {
		ModelAndView mv = new ModelAndView();
		try
		{
		dao.updateStudent(bean);
		}
		catch(Exception e)
		{
			
		}
		mv.addObject("value", bean);
		return mv;
	}

	@RequestMapping("FindPage")
	public ModelAndView locateFind() {
		List<Integer> list = dao.getIdlist();
		ModelAndView mv = new ModelAndView("FindPage");
		mv.addObject("idList", list);
		return mv;
	}

	@RequestMapping("performSearch")
	public ModelAndView performSearch(@ModelAttribute("bean") School bean) {
		School sc = dao.findStudent(bean);
		ModelAndView mv = new ModelAndView("FindResult");
		mv.addObject("value", sc);
		return mv;
	}

	@RequestMapping("ViewAllPage")
	public ModelAndView locateViewAll() {
		List<School> StList = dao.viewAllStudent();
		ModelAndView mv = new ModelAndView("ViewAllPage");
		mv.addObject("StList", StList);
		return mv;
	}

}
