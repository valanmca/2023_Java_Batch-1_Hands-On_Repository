import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;


public class CompanyTag extends SimpleTagSupport {

	public void dotag() throws IOException
	{
		JspWriter out = getJspContext().getOut();
		out.println("NAN MSG");
	}
}
