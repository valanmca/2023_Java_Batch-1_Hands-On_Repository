package com.hms.dao;

import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hms.bean.Doctor;
import com.hms.util.DBUtil;

public class Doctordao {
	
	Transaction transaction;
	Session session;
	
	
	public void insertDoctor(Doctor bean) {
		session=DBUtil.getSession();
		transaction=session.beginTransaction();
		
		session.save(bean);
		transaction.commit();
		session.close();
	}
	public void deleteDoctor(Doctor bean) {
		session=DBUtil.getSession();
		transaction=session.beginTransaction();
		
		session.delete(bean);
		transaction.commit();
		session.close();
	}
	
	//delete and find 
	public List<Integer> getIdList(){
		
		session=DBUtil.getSession();
		transaction=session.beginTransaction();
		Query query = session.createQuery("select DoctorId from Doctor");
		List <Integer> list = query.list();
		transaction.commit();
		session.close();
		return list;
	}
	
	
	public void updateDoctor(Doctor bean) {
		session=DBUtil.getSession();
		transaction=session.beginTransaction();
		
		session.update(bean);
		transaction.commit();
		session.close();
	}
	
	public Doctor findDoctor(Doctor bean) {
		session =DBUtil.getSession();
		transaction = session.beginTransaction();
		Doctor doc = session.get(Doctor.class,bean.getDoctorId());
		transaction.commit();
		session.close();
		return doc;
	}
	
    //findall
    public List<Integer> getAllList( )
    {
        session=DBUtil.getSession();
        transaction =session.beginTransaction();
        Query query =session.createQuery("from Doctor");
        List <Integer>list=query.list();
        transaction.commit();
        session.close();
        return list;
        
    }
	
	
	
	

}
