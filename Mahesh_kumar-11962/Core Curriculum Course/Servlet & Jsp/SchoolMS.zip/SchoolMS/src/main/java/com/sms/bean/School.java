package com.sms.bean;

public class School {

	private int id;
	private String name;
	private int dno;

	public School() {
		super();
		// TODO Auto-generated constructor stub
	}

	public School(int id, String name, int dno) {
		super();
		this.id = id;
		this.name = name;
		this.dno = dno;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDno() {
		return dno;
	}

	public void setDno(int dno) {
		this.dno = dno;
	}

	public void display() {

		System.out.println("Student id : " + id);
		System.out.println("Student Name : " + name);
		System.out.println("Student Deptno : " + dno);
		System.out.println("\t--*--");

	}

}
