package com.hms;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hms.bean.Hospital;
import com.hms.dao.HospitalDAO;

@Controller
public class HmsController {
	HospitalDAO dao = new HospitalDAO();

	@RequestMapping("operations")
	public ModelAndView locationOperation() {
		ModelAndView mv = new ModelAndView("operations");
		return mv;
	}

	@RequestMapping("window")
	public ModelAndView locationwindow() {
		ModelAndView mv = new ModelAndView("window");
		return mv;
	}

	@RequestMapping("navbar")
	public ModelAndView locationnavbar() {
		ModelAndView mv = new ModelAndView("navbar");
		return mv;
	}

	@RequestMapping("InsertPage")
	public ModelAndView locateInsert() {
		ModelAndView mv = new ModelAndView("InsertPage");
		return mv;
	}

	@RequestMapping("InsertDetails")
	public ModelAndView performInsert(@ModelAttribute("bean") Hospital bean) {
		ModelAndView mv = new ModelAndView();
		try {

			dao.insertPatient(bean);
			mv.setViewName("InsertSuccess");
		} catch (Exception e) {
			mv.setViewName("InsertFail");

		}

		return mv;
	}
	@RequestMapping("UpdatePage")
	public ModelAndView locateUpdate() {
		ModelAndView mv = new ModelAndView("UpdatePage");
		return mv;
	}

	@RequestMapping("UpdateDetails")
	public ModelAndView performUpdate(@ModelAttribute("bean") Hospital bean) {
		ModelAndView mv = new ModelAndView();
		try {

			dao.updatePatient(bean);
			mv.setViewName("UpdateSuccess");
		} catch (Exception e) {
			mv.setViewName("UpdateFail");

		}

		return mv;
	}
}
