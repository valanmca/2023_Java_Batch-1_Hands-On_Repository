package com.modeltms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbModelTmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbModelTmsApplication.class, args);
	}

}
