package com.vms.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.vms.bean.Vehicle;
import com.vms.util.DbUtill;

public class VehicleDAO {

	Session session;
	Transaction transaction;
	
	public void insertVehicleDetails(Vehicle bean)
	{
		Session session= DbUtill.getSession();
		transaction = session.beginTransaction();
		session.save(bean);
		transaction.commit();
		session.close();
	}
}
