package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("uname");
		String password = request.getParameter("pwd");

		PrintWriter out = response.getWriter();
		/*
		 * if (userName.equals("Admin") && password.equals("123")) {
		 * out.print("<font color = 'green'><b> Welcome Admin</b></font>"); } else {
		 * out.print("<font color = 'red'><b> Invalid Username & Password</b></font>");
		 * } 
		 */

		if (password.equals("123")) {
			response.sendRedirect("SuccessMsg.jsp?userName=" + userName);
		} else {
			response.sendRedirect("FailMsg.jsp");
		}

	}

}
