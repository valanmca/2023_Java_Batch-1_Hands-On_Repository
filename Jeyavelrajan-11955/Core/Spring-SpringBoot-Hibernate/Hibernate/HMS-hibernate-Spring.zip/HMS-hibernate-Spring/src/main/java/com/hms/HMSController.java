package com.hms;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hms.bean.Doctor;
import com.hms.dao.Doctordao;
@Controller
public class HMSController {
	
	@Autowired
	Doctordao dao;
	
	@RequestMapping("DocHead")
	public ModelAndView loadDocHead() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("DocHead");
		return mv;
	}
	
	@RequestMapping("insertDoctor")
	public ModelAndView loadInsertDoctor() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("insertDoctor");
		return mv;
	}
	
	@RequestMapping("PerformInsert")
		public ModelAndView performInsertDoctor(@ModelAttribute("bean") Doctor bean) {
		            
		  
		    ModelAndView mv = new ModelAndView();
		    try {
		    	  dao.insertDoctor(bean);
		    	  mv.setViewName("insertDoctorSuccess");

		    }catch(Exception e){
		    	
		    	mv.setViewName("insertDoctorFail");
		    }
		   return mv;
	}
	
	
	@RequestMapping("deleteDoctor")
	public ModelAndView loadDeleteDoctor() 
	{
		List<Integer> list=dao.getIdList();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("deleteDoctor");
		mv.addObject("idList",list);
		return mv;
	}
	
	
	@RequestMapping("PerformDelete")
	public ModelAndView performDeleteDoctor(@ModelAttribute("bean") Doctor bean) {
	            
	    {
	        dao.deleteDoctor(bean);
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("deleteDoctorSuccess");
	        return mv;
	    }
	}
	
	
	
	@RequestMapping("updateDoctor")
	public ModelAndView loadUpdateDoctor() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("updateDoctor");
		return mv;
	}
	
	
	@RequestMapping("PerformUpdate")
	public ModelAndView performUpdateDoctor(@ModelAttribute("bean") Doctor bean) {
	            
	  
	    ModelAndView mv = new ModelAndView();
	    try {
	    	  dao.updateDoctor(bean);
	    	  mv.setViewName("updateDoctorSuccess");

	    }catch(Exception e){
	    	
	    	mv.setViewName("updateDoctorFail");
	    }
	   return mv;
}
	
	@RequestMapping("findDoctor")
	public ModelAndView loadFindDoctor() 
	{
		List<Integer> list=dao.getIdList();
		ModelAndView mv = new ModelAndView();
		mv.setViewName("findDoctor");
		mv.addObject("idList2",list);
		return mv;
	
	
	}
	
	 @RequestMapping("PerformFind")
	    public ModelAndView findEmployee(@ModelAttribute("bean") Doctor bean)
	    {
	        Doctor value=dao.findDoctor(bean);
	        
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("findDoctorSuccess");
	        mv.addObject("doc",value);
	        return mv;
	    }
	 
	 @RequestMapping("findAllDoctor")
	    public ModelAndView FindAllDoctor()
	    {
	        List<Integer> list=dao.getAllList();
	        ModelAndView mv=new ModelAndView();
	        mv.setViewName("findAllDoctor");
	        mv.addObject("idList1",list);
	        return mv;
	    }
	
	
	

}
