package com.hms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.bean.Hospital;
import com.hms.dao.HospitalDAO;

@WebServlet("/hmsControll")
public class hmsControll extends HttpServlet {

	HospitalDAO dao = new HospitalDAO();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		String reqFrom = request.getParameter("hmsbtn");

		if (reqFrom.equals("Insert")) {
			int id = Integer.parseInt(request.getParameter("Did"));
			String name = request.getParameter("Dname");
			int depid = Integer.parseInt(request.getParameter("Ddepid"));

			Hospital bean = new Hospital(id, name, depid);

			int resResult = dao.insertDoctorDetails(bean);

			if (resResult == 1) {
				response.sendRedirect("InsertSuccess.jsp");
			} else {
				response.sendRedirect("InsertFail.jsp");
			}
		}

		if (reqFrom.equals("Delete")) {
			int id = Integer.parseInt(request.getParameter("Did"));

			int delResult = dao.deleteDoctorDetails(id);

			if (delResult == 1) {
				response.sendRedirect("DeleteSuccess.jsp");
			} else {
				response.sendRedirect("DeleteFail.jsp");
			}

		}

		if (reqFrom.equals("Update")) {
			int id = Integer.parseInt(request.getParameter("Did"));
			String name = request.getParameter("Dname");
			int depid = Integer.parseInt(request.getParameter("Ddepid"));

			Hospital bean = new Hospital(id, name, depid);

			int resResult = dao.updateDoctorDetails(bean);

			if (resResult == 1) {
				response.sendRedirect("UpdateSuccess.jsp");
			} else {
				response.sendRedirect("UpdateFail.jsp");
			}
		}

		if (reqFrom.equals("Find")) {
			int id = Integer.parseInt(request.getParameter("Did"));

			Hospital bean = dao.findDocor(id);

			RequestDispatcher rd = request.getRequestDispatcher("FindSuccess.jsp");
			request.setAttribute("bean", bean);
			rd.forward(request, response);

		}

	}
	

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		
		ArrayList<Hospital> lst = new ArrayList<Hospital>();
		lst = dao.viewallDoctorDetails();
		RequestDispatcher rd = request.getRequestDispatcher("ViewAllPage.jsp");
		request.setAttribute("msg", lst);
		rd.forward(request, response);

	}
	
	



}
