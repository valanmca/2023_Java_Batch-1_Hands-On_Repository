package com.lms.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;

import com.lms.bean.Course;
import com.lms.bean.Enrollment;
import com.lms.repo.CourseRepository;
import com.lms.repo.EnrollementRepository;


public class EnrollmentService {

	
	@Autowired
	private EnrollementRepository enrollRep;
	
	 
	public List<Enrollment> getAllFiles() {
		return (List<Enrollment>) enrollRep.findAll();
	}

	public boolean enroll(Enrollment enroll) {
		
		enrollRep.save(enroll);
		return true;
	}	


	public boolean unenroll(@PathVariable("id") long id) {
		enrollRep.deleteById(id);
		return true;
	}

	public List<Enrollment> getAll() {
		Iterator<Enrollment> it = enrollRep.findAll().iterator();
		List<Enrollment> list = new ArrayList<Enrollment>();
		while (it.hasNext()) {
			list.add((Enrollment) it.next());
		}
		return list;
	}


}
