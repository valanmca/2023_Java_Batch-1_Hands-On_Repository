package com.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbPmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbPmsApplication.class, args);
	}

}
