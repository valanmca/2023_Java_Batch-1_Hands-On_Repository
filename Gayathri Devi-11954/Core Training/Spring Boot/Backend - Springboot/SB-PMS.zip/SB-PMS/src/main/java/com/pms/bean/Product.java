package com.pms.bean;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tbl_pms")
public class Product {

	@Id
	@Column(name = "price")
	private int price;
	
	@Column(name = "name")
	private String productName;

	@Column(name = "category")
	private String Category;

	@Column(name = "date")
	private String date;

	@Column(name = "fresh")
	private String freshness;


	@Column(name = "comment")
	private String comment;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(String productName, String category, String date, String freshness, int price, String comment) {
		super();
		this.productName = productName;
		Category = category;
		this.date = date;
		this.freshness = freshness;
		this.price = price;
		this.comment = comment;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getFreshness() {
		return freshness;
	}

	public void setFreshness(String freshness) {
		this.freshness = freshness;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@Override
	public String toString() {
		return "Product [productName=" + productName + ", Category=" + Category + ", date=" + date + ", freshness="
				+ freshness + ", price=" + price + ", comment=" + comment + "]";
	}

}
