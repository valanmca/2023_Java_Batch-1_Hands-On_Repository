package com.hms.bean;

public class Hospital {
	
	private int doctorId;
	private String doctorName;
	private int doctorDepId;
	
	public Hospital() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospital(int doctorId, String doctorName, int doctorDepId) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorDepId = doctorDepId;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getDoctorDepId() {
		return doctorDepId;
	}

	public void setDoctorDepId(int doctorDepId) {
		this.doctorDepId = doctorDepId;
	}

		
}
