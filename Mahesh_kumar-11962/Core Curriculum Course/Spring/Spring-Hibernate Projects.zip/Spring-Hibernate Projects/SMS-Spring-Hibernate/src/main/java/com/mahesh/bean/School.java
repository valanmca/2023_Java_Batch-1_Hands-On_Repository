package com.mahesh.bean;


import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;
import javax.persistence.Column;


@Entity
@Table(name="tbl_student")
public class School {

	@Id
	@Column(name="sid")
	private int sid;
	
	@Column(name="sname")
	private String sname;
	
	@Column(name="sdep")
	private String sdep;
	
	@Column(name="sfees")
	private int sfees;
	
	public School() {
		super();
	}

	public School(int sid, String sname, String sdep, int sfees) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.sdep = sdep;
		this.sfees = sfees;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSdep() {
		return sdep;
	}

	public void setSdep(String sdep) {
		this.sdep = sdep;
	}

	public int getSfees() {
		return sfees;
	}

	public void setSfees(int sfees) {
		this.sfees = sfees;
	}

	@Override
	public String toString() {
		return "School [sid=" + sid + ", sname=" + sname + ", sdep=" + sdep + ", sfees=" + sfees + "]";
	}
	
	
	
	
	
}
