package com.vms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_bike")
public class Vehicle {
	@Id
	@Column(name="vehicle_Id")
	private int vehicleId;
	@Column(name="vehicle_name")
	private String vehicleName;
	@Column(name="vehicle_brand")
	private String vehicleBrand;
	@Column(name="")
	private int vehiclePrice;
	
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Vehicle(int vehicleId, String vehicleName, String vehicleBrand, int vehiclePrice) {
		super();
		this.vehicleId = vehicleId;
		this.vehicleName = vehicleName;
		this.vehicleBrand = vehicleBrand;
		this.vehiclePrice = vehiclePrice;
	}

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public String getVehicleBrand() {
		return vehicleBrand;
	}

	public void setVehicleBrand(String vehicleBrand) {
		this.vehicleBrand = vehicleBrand;
	}

	public int getVehiclePrice() {
		return vehiclePrice;
	}

	public void setVehiclePrice(int vehiclePrice) {
		this.vehiclePrice = vehiclePrice;
	}

	
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" 
				+ vehicleName + ", vehicleBrand=" + vehicleBrand
				+ ", vehiclePrice=" + vehiclePrice + "]";
	}
	
	

}
