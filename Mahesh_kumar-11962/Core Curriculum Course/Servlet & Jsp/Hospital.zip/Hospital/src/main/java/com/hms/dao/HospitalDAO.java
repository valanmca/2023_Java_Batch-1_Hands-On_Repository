package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


import com.hms.bean.Hospital;
import com.hms.util.DBUtil;


public class HospitalDAO {

	public int insertDoctorDetails(Hospital Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "insert into tbl_hospital values(?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, Bean.getDoctorId());
			ps.setString(2, Bean.getDoctorName());
			ps.setInt(3, Bean.getDoctorDepId());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int deleteDoctorDetails(int id) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "delete from tbl_hospital where doctor_id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int updateDoctorDetails(Hospital Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "update tbl_hospital set doctor_name=?,doctor_depid=? where doctor_id=?";
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, Bean.getDoctorName());
			ps.setInt(2, Bean.getDoctorDepId());
			ps.setInt(3, Bean.getDoctorId());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public Hospital findDocor(int id) {
		Hospital bean = null;

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_hospital where doctor_id =?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet re = ps.executeQuery();
			if (re.next()) {

				bean = new Hospital();
				bean.setDoctorId(re.getInt("doctor_id"));
				bean.setDoctorName(re.getString("doctor_name"));
				bean.setDoctorDepId(re.getInt("doctor_depid"));

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return bean;
	}

	public ArrayList<Hospital> viewallDoctorDetails() {
		ArrayList<Hospital> list = new ArrayList<Hospital>();

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_hospital";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet re = ps.executeQuery();
			while (re.next()) {

				Hospital bean = new Hospital();
				bean.setDoctorId(re.getInt("doctor_id"));
				bean.setDoctorName(re.getString("doctor_name"));
				bean.setDoctorDepId(re.getInt("doctor_depid"));
				list.add(bean);

			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return list;

	}
}
