package com.vems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.vems.util.DBUtil;
import com.vems.bean.Vehicle;

public class VehicleDAO {

	public int insertVehicleDetails(Vehicle Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "insert into tbl_vehicle values(?,?,?,?,?)";
			// ex : insert into tbl_vehicle value(1,"gear","shine110","7879","jeyavel");
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, Bean.getVehicleId());
			ps.setString(2, Bean.getVehicleType());
			ps.setString(3, Bean.getVehicleName());
			ps.setInt(4, Bean.getVehicleNumber());
			ps.setString(5, Bean.getOwnerName());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int deleteVehicleDetails(int id) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "delete from tbl_vehicle where Vehicle_id = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			n = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public int updateVehicleDetails(Vehicle Bean) {
		int n = 0;
		try {

			Connection con = DBUtil.getDBconnection();
			String sql = "update tbl_vehicle set Vehicle_type=?,Vehicle_name=?,Vehicle_no=?,Vehicle_owner=? where Vehicle_id=?";
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, Bean.getVehicleType());
			ps.setString(2, Bean.getVehicleName());
			ps.setInt(3, Bean.getVehicleNumber());
			ps.setString(4, Bean.getOwnerName());
			ps.setInt(5, Bean.getVehicleId());

			n = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return n;
	}

	public Vehicle searchVehicle(int id) {
		Vehicle bean = null;

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_vehicle where Vehicle_id =?";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet re = ps.executeQuery();
			if (re.next()) {

				bean = new Vehicle();

				bean.setVehicleId(re.getInt("Vehicle_id"));
				bean.setVehicleType(re.getString("Vehicle_type"));
				bean.setVehicleName(re.getString("Vehicle_name"));
				bean.setVehicleNumber(re.getInt("Vehicle_no"));
				bean.setOwnerName(re.getString("Vehicle_owner"));

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return bean;
	}

	public ArrayList<Vehicle> viewallVehicleDetails() {
		ArrayList<Vehicle> list = new ArrayList<Vehicle>();

		try {
			Connection con = DBUtil.getDBconnection();
			String sql = "select * from tbl_vehicle";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet re = ps.executeQuery();
			while (re.next()) {

				Vehicle bean = new Vehicle();

				bean.setVehicleId(re.getInt("Vehicle_id"));
				bean.setVehicleType(re.getString("Vehicle_type"));
				bean.setVehicleName(re.getString("Vehicle_name"));
				bean.setVehicleNumber(re.getInt("Vehicle_no"));
				bean.setOwnerName(re.getString("Vehicle_owner"));

				list.add(bean);

			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return list;

	}
}
