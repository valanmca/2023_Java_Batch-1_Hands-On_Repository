package com.tms.bean;
public class Teacher{
	
int TeacherId;
String TeacherName;
String TeacherEmail;
String TeacherQualification;
String TeacherLocation;



	public Teacher() {
	super();
	// TODO Auto-generated constructor stub
}



	public Teacher(int teacherId, String teacherName, String teacherEmail, String teacherQualification,
			String teacherLocation) {
		super();
		TeacherId = teacherId;
		TeacherName = teacherName;
		TeacherEmail = teacherEmail;
		TeacherQualification = teacherQualification;
		TeacherLocation = teacherLocation;
	}



	public int getTeacherId() {
	return TeacherId;
}



public void setTeacherId(int teacherId) {
	TeacherId = teacherId;
}



public String getTeacherName() {
	return TeacherName;
}



public void setTeacherName(String teacherName) {
	TeacherName = teacherName;
}



public String getTeacherEmail() {
	return TeacherEmail;
}



public void setTeacherEmail(String teacherEmail) {
	TeacherEmail = teacherEmail;
}



public String getTeacherQualification() {
	return TeacherQualification;
}



public void setTeacherQualification(String teacherQualification) {
	TeacherQualification = teacherQualification;
}



public String getTeacherLocation() {
	return TeacherLocation;
}



public void setTeacherLocation(String teacherLocation) {
	TeacherLocation = teacherLocation;
}



	public void display() {
		System.out.println("\t--*--");
		System.out.println("Teacher Id : " + TeacherId);
		System.out.println("Teacher Name : " + TeacherName);
		System.out.println("Teacher Email : " + TeacherEmail);
		System.out.println("Teacher Qualification : " + TeacherQualification);
		System.out.println("Teacher Location : " + TeacherLocation);
		System.out.println("\t--*--");
	}

}
