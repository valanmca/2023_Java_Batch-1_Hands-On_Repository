import { Component } from '@angular/core';
import {FormControl, FormGroup, Validators } from '@angular/forms';
import { Doctor } from './model/doctor';
import { DoctorService } from './doctor.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  myForm : FormGroup;
   doctor:Doctor;
  result:string=" ";
  doclist:Doctor[]=[];

  constructor(private doc:DoctorService){
    this.myForm=new FormGroup({
      id: new FormControl('',[Validators.required,Validators.pattern('[0-9]+')]),
      name: new FormControl('',[Validators.required,Validators.pattern('[A-Za-z]+')]),
      age: new FormControl('',[Validators.required,Validators.pattern('[0-9]+')]),
      email: new FormControl('',[Validators.required]),
      specialization: new FormControl('',[Validators.required]),
      contactnumber: new FormControl('',[Validators.required,Validators.pattern('[0-9]+')]),
      location: new FormControl('',[Validators.required])
    });
    this.doctor=new Doctor();
    this.getAll();
  }

  insertDetails(data:any){
    this.doctor.id=data.id;
    this.doctor.name=data.name;
    this.doctor.age=data.age;
    this.doctor.email=data.email;
    this.doctor.specialization=data.specialization;
    this.doctor.contactnumber=data.contactnumber;
    this.doctor.location=data.location;
    
    this.result=this.doc.insertDetails(this.doctor);
    this.getAll();
  }
  updateDetails(data:any){
    this.doctor.id=data.id;
    this.doctor.name=data.name;
    this.doctor.age=data.age;
    this.doctor.email=data.email;
    this.doctor.specialization=data.specialization;
    this.doctor.contactnumber=data.contactnumber;
    this.doctor.location=data.location;
    
    this.result=this.doc.updateDetails(this.doctor);
    this.getAll();
  }
  deleteDetails(data:any){
    this.doctor.id=data.id;
    this.doctor.name=data.name;
    this.doctor.age=data.age;
    this.doctor.email=data.email;
    this.doctor.specialization=data.specialization;
    this.doctor.contactnumber=data.contactnumber;
    this.doctor.location=data.location;
    
    this.result=this.doc.deleteDetails(this.doctor);
    this.getAll();
  }
  getAll() {
    this.doc.getAllDetails().subscribe(doctor => this.doclist = doctor);
  }



}
