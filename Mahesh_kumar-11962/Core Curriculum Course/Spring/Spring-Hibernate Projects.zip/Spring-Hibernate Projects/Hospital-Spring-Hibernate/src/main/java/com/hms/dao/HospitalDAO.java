package com.hms.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hms.bean.Hospital;
import com.hms.util.DbUtil;

public class HospitalDAO {

	
	Session session;
	Transaction transaction;
	
	public void insertPatient(Hospital bean)
	{
	
		session = DbUtil.getSession();
		transaction=session.beginTransaction();
		session.save(bean);
		transaction.commit();
		session.close();
	}
	
	
	public void updatePatient(Hospital bean)
	{
	
		session = DbUtil.getSession();
		transaction=session.beginTransaction();
		session.update(bean);
		transaction.commit();
		session.close();
	}
}
