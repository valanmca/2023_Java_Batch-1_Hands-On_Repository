package com.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hms.bean.Doctor;
import com.hms.util.DBUtil;

public class DoctorDAO {

	public int insertDoctor(Doctor bean) {
		int n=0;
		try {
			Connection con=DBUtil.getDBConnection();
			String sql= "insert into tbl_hospital values(?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1,bean.getDoctorId());
			ps.setString(2,bean.getDoctorName());
			ps.setString(3,bean.getDoctorSpecialization());
			ps.setInt(4,bean.getDoctorSalary());
			n = ps.executeUpdate();
		}catch(Exception e) {
			System.out.println(e);
		}
		return n;
		
	}
public int deleteDoctor	(int id) {
	int n=0;
	try {
		Connection con=DBUtil.getDBConnection();
		String sql= "delete from tbl_hospital where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1,id);
		n = ps.executeUpdate();
	}catch(Exception e) {
		System.out.println(e);
	}
	return n;
}
public int updateDoctor(Doctor bean) {
	int n1=0;
	try {
		Connection con=DBUtil.getDBConnection();
		String sql= "update tbl_hospital set DoctorName =?,DoctorSpecialization =?,DoctorSalary =? where DoctorId =?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1,bean.getDoctorId());
		ps.setString(2,bean.getDoctorName());
		ps.setString(3,bean.getDoctorSpecialization());
		ps.setInt(4,bean.getDoctorSalary());
		n1 = ps.executeUpdate();
	}catch(Exception e) {
		System.out.println(e);
	}
	return n1;
	
}
public Doctor findDoctor(int id) {
	Doctor bean = null;
	try {
		Connection con = DBUtil.getDBConnection();
		String sql = "select*from tbl_hospital where DoctorId= ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		ResultSet rs = ps.executeQuery();
		if(rs.next()) {
			bean = new Doctor();
			bean.setDoctorId(rs.getInt("DoctorId"));
			bean.setDoctorName(rs.getString("DoctorName"));
			bean.setDoctorSalary(rs.getInt("DoctorSalary"));
			bean.setDoctorSpecialization(rs.getString("DoctorSpecialization"));
		}
		
	}catch(Exception e){
		System.out.println(e);
	}
	return bean;
}
public List<Doctor> findAllDoctor(){
	List<Doctor> list = new ArrayList<Doctor>();
	try {
		Connection con =DBUtil.getDBConnection();
		String sql = "select * from tbl_hospital";
		PreparedStatement ps = con.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			Doctor bean = new Doctor();
			bean.setDoctorId(rs.getInt("doctorId"));
			bean.setDoctorName(rs.getString("doctorName"));
			bean.setDoctorSalary(rs.getInt("doctorSalary"));
			bean.setDoctorSpecialization(rs.getString("doctorSpecialization"));
		}
	}catch(Exception e){
		System.out.println();
	}
	return list;
	
}

}


