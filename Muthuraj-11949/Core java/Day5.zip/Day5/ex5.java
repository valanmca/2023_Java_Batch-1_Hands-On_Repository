package Day5;
public class ex5 {
	public static void main(String[] args) {
for(int i = 0; i <= 5; i++) {
  System.out.println("Yes");
     }
  }
}
