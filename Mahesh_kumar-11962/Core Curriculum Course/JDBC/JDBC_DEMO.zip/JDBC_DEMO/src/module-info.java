/**
 * 
 */
/**
 * 
 */
module JDBC_DEMO {
	requires java.sql;
}