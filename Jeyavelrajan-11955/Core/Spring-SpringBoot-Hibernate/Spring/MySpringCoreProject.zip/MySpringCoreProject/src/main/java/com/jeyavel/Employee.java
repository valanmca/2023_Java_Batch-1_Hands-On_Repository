package com.jeyavel;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Employee {
     private int id;
     private String name;
     private int salary;
     private List<String> placesVisited;
     private Map <String,String> college;
     private Set <Integer> Experience;
     private Address address;
     
     
     
     
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Employee(int id, String name, int salary, List<String> placesVisited, Map<String, String> college,
			Set<Integer> experience, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.placesVisited = placesVisited;
		this.college = college;
		Experience = experience;
		this.address = address;
	}



	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}


	public List<String> getPlacesVisited() {
		return placesVisited;
	}


	public void setPlacesVisited(List<String> placesVisited) {
		this.placesVisited = placesVisited;
	}


	public Map<String, String> getCollege() {
		return college;
	}


	public void setCollege(Map<String, String> college) {
		this.college = college;
	}


	public Set<Integer> getExperience() {
		return Experience;
	}


	public void setExperience(Set<Integer> experience) {
		Experience = experience;
	}


	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", placesVisited=" + placesVisited
				+ ", college=" + college + ", Experience=" + Experience + ", address=" + address + "]";
	}




     
	
//	public void display () {
//		System.out.println("Employee id: "+id );
//		System.out.println("Employee Name:"+name);
//		System.out.println("Employee Salary:"+salary);
//		System.out.println("Address :"+address.toString());
//	}



     
	
     
}
