package com.hms.bean;

public class Doctor {
	private int DoctorId;
	private String DoctorName;
	private String DoctorSpecialization;
	private int DoctorSalary;
	
	
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Doctor(int doctorId, String doctorName, String doctorSpecialization, int doctorSalary) {
		super();
		DoctorId = doctorId;
		DoctorName = doctorName;
		DoctorSpecialization = doctorSpecialization;
		DoctorSalary = doctorSalary;
	}


	public int getDoctorId() {
		return DoctorId;
	}


	public void setDoctorId(int doctorId) {
		DoctorId = doctorId;
	}


	public String getDoctorName() {
		return DoctorName;
	}


	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}


	public String getDoctorSpecialization() {
		return DoctorSpecialization;
	}


	public void setDoctorSpecialization(String doctorSpecialization) {
		DoctorSpecialization = doctorSpecialization;
	}


	public int getDoctorSalary() {
		return DoctorSalary;
	}


	public void setDoctorSalary(int doctorSalary) {
		DoctorSalary = doctorSalary;
	}
	
	
	

}
