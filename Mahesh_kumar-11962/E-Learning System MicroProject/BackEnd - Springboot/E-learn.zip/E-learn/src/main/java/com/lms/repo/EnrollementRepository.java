package com.lms.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.bean.Enrollment;

public interface EnrollementRepository extends JpaRepository<Enrollment, Long> {

}
