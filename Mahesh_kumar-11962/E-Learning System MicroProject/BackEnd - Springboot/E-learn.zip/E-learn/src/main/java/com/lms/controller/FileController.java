package com.lms.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.lms.bean.FileData;
import com.lms.service.FileService;

@RestController
public class FileController {

	@Autowired
	private FileService service;
	
	
	
	@PostMapping("/uploadpdf")
	public String uploadpdf(@RequestParam("file") MultipartFile file) throws IOException
	{
		FileData fileName = service.storeFile(file);
		return "uploaded";
	}
	
	
	
}
