package databas;
import java.sql.*;
class Student {

	public static void main(String[] args)throws SQLException {
		
		String Url="jdbc:mysql://localhost:3306/Student";
		String Username ="root";
		String Password ="Pa55w0rd@2k23";
		Connection con = DriverManager.getConnection(Url,Username,Password);
		Statement st = con.createStatement();
		
		System.out.println("");
		
		// Select query
		String selectQuery = "select * from tbl_student";
		
		ResultSet res = st.executeQuery(selectQuery);
		
		while(res.next())
		{
		System.out.println("Student Id : "+res.getInt(1));
		System.out.println("Student Name : "+res.getString(2));
		System.out.println("Student Department : "+res.getString(3));
		System.out.println();
		}
		
		/*Insert query
		
		
		String InsertQuery = "insert into tbl_student values(3,'kani','Viscom')";
		int row = st.executeUpdate(InsertQuery);
		System.out.println(row+" rows affected");
		
		
		String InsertQuery = "insert into tbl_student values(4,'karthi','Commerce')";
		int row = st.executeUpdate(InsertQuery);
		System.out.println(row+" rows affected");
	
		//Update query
		String UpdateQuery = "update tbl_student set student_name ='Domnic Dev',student_dept='BCA' where student_id=2";
		int row_result = st.executeUpdate(UpdateQuery);
		System.out.println(row_result+" rows affected");
		
	*/
		//Delete Query
		String DeleteQuery ="delete from tbl_student where student_id=4";
		int row_result = st.executeUpdate(DeleteQuery);
		System.out.println(row_result+" rows affected");
	}

}
