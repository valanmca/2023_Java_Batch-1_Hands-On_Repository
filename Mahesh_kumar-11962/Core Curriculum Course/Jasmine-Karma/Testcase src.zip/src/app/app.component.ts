import { Component, numberAttribute } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngTestCaseTASK';



  fact(val: number): number {
    var fact: number = 1;
    if (val >= 0) {
      for (var index = 1; index <= val; index++) {
        fact = fact * index;
      }

    }
    else {

      return 0;
    }

    return fact;

  }

  add(fnum: number, snum: number): number {
    return fnum + snum;

  }

  subract(fnum: number, snum: number): number {
    return fnum - snum;

  }
  multiply(fnum: number, snum: number): number {
    return fnum * snum;

  }
  divide(fnum: number, snum: number): number {
    return fnum / snum;

  }
  modulo(fnum: number, snum: number): number {
    return fnum % snum;

  }

  isPrime(num: number): boolean {
    if (num <= 1) return false; // Numbers less than or equal to 1 are not prime
    if (num <= 3) return true; // 2 and 3 are prime numbers

    // Check divisibility by 2 and 3
    if (num % 2 === 0 || num % 3 === 0) return false;

    let i = 5;
    while (i * i <= num) {
        if (num % i === 0 || num % (i + 2) === 0) return false;
        i += 6;
    }

    return true;
}

}

