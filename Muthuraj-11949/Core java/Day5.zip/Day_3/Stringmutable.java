package Day_3;

public class Stringmutable {
/// in this Method mutable String  
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringBuffer sb= new StringBuffer("java");
		sb.append("world");
		System.out.println(sb);//Java World
	}
	}

