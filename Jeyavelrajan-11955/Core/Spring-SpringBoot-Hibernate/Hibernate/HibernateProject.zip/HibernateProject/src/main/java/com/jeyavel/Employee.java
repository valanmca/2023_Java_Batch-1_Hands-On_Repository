package com.jeyavel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries({
//	@NamedQuery(name="selectAllEmployee", query="from Employee")
	@NamedQuery(name="SelectEmployee" , query="from tbl_employee where id = 11955")
})


@Entity
@Table(name="tbl_employee")
public class Employee {
	@javax.persistence.Id
	@Column(name="Id")
	private int Id;
	@Column(name="Name")
	private String Name;
	@Column(name="Salary")
	private int Salary;
	@Column(name="Dno")
	private int Dno;
	
	
	public Employee() {
		super();
		
	}
	
	
	public Employee(int Id, String Name, int Salary, int Dno) {
		this.Id = Id;
		this.Name = Name;
		this.Salary = Salary;
		this.Dno = Dno;
	}


	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public int getDno() {
		return Dno;
	}
	public void setDno(int dno) {
		Dno = dno;
	}


	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + ", Dno=" + Dno + "]";
	}




	
	

	
	
}
