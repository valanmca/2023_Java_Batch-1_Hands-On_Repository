package com.ems.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ems.bean.Employee;
import com.ems.dao.EmployeeDAO;

/**
 * Servlet implementation class EmsController
 */
@WebServlet("/EmsController")
public class EmsController extends HttpServlet {
	EmployeeDAO dao = new EmployeeDAO();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String requestFrom = request.getParameter("ems_button");

		if (requestFrom.equals("Insert Employee")) {
			int id = Integer.parseInt(request.getParameter("eid"));
			String name = request.getParameter("ename");
			int dno = Integer.parseInt(request.getParameter("edep"));

			Employee bean = new Employee(id, name, dno);
			int Insertres = dao.insertEmployee(bean);

			if (Insertres == 1) {
				response.sendRedirect("InsertEmployeeSuccess.jsp");
			} else {
				response.sendRedirect("InsertEmployeeFail.jsp");
			}
		}

		if (requestFrom.equals("Update Employee")) {
			int id = Integer.parseInt(request.getParameter("eid"));
			String name = request.getParameter("ename");
			int dno = Integer.parseInt(request.getParameter("edep"));

			Employee bean = new Employee(id, name, dno);
			int Updateres = dao.updateEmployee(bean);

			if (Updateres == 1) {
				response.sendRedirect("UpdateEmployeeSuccess.jsp");
			} else {
				response.sendRedirect("UpdateEmployeeFail.jsp");
			}
		}

		if (requestFrom.equals("Delete Employee")) {
			int id = Integer.parseInt(request.getParameter("eid"));

			int Delres = dao.deleteEmployee(id);

			if (Delres == 1) {
				response.sendRedirect("DeleteEmployeeSuccess.jsp");
			} else {
				response.sendRedirect("DeleteEmployeeFail.jsp");
			}
		}

		if (requestFrom.equals("Find Employee")) {
			int id = Integer.parseInt(request.getParameter("eid"));

			Employee bean = dao.findEmloyee(id);

			RequestDispatcher rd = request.getRequestDispatcher("FindEmployeeSuccess.jsp");
			request.setAttribute("bean", bean);
			rd.forward(request, response);

		}

	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Employee> lst = dao.viewallEmployee();

		RequestDispatcher rd = request.getRequestDispatcher("FindAllEmployee.jsp");
		request.setAttribute("lst", lst);
		rd.forward(request, response);
	}
}