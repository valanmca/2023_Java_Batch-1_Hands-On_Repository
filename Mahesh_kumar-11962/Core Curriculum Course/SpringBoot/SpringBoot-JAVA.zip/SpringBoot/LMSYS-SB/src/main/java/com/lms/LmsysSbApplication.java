package com.lms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmsysSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(LmsysSbApplication.class, args);
	}

}
