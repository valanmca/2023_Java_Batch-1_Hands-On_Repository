package com.gayathri.own.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.gayathri.own.bean.ProductBean;
import com.gayathri.own.util.ProductDbUtil;

public class ProductDao {
	
	Transaction transaction;
	Session session;
	public void insertProduct(ProductBean bean) {
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		session.save(bean);
		transaction.commit();
		session.close();		
	}
	public void updateProduct(ProductBean bean) {
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		session.update(bean);
		transaction.commit();
		session.close();
	}
	public void deleteProduct(ProductBean bean) {
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		session.delete(bean);
		transaction.commit();
		session.close();
	}
	
	public List <Integer> getIDList(){
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		Query query = session.createQuery("select pId from ProductBean");
		List<Integer> proList = query.list();
		return proList;
	}
	
	public ProductBean searchProduct(ProductBean bean) {
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		ProductBean pro = session.get(ProductBean.class, bean.getpId());
		transaction.commit();
		session.close();	
		return pro;
	}
	public List<ProductBean> performView() {
		session = ProductDbUtil.getSession();
		transaction = session.beginTransaction();
		Query query = session.createQuery("from ProductBean");
		List<ProductBean> proList = query.list();
		return proList;
	}
	
	
	

}
