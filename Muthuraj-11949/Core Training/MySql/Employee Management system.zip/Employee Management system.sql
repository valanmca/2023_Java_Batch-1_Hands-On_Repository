create database Kumar1;
use Kumar1;
Create table employees12( emp_Id int Primary key,fname varchar(255),lname varchar(255),gender int,age int,contact_add int(11),emp_email varchar(255),emp_pass varchar(255));
create table Jobdepartment1( job_id int primary key,job_dept varchar(30) ,name varchar(30),description varchar(30),salary_range varchar(30));
create table salaryb (salary_id int primary key,job_id int, FOREIGN KEY(job_id) REFERENCES Jobdepartment1(job_id));
create table Qualification1 (qual_id int primary key,emp_Id int, FOREIGN KEY(emp_Id) REFERENCES employees12(emp_Id),position varchar(30),requriments varchar(30),date_in Date);
create table leave1(leave_id int primary key,emp_Id int, FOREIGN KEY(emp_Id) REFERENCES employees12(emp_Id),date_in Date,reason varchar(30));
create table payroll1 (payroll_id int Primary key,emp_Id int, FOREIGN KEY(emp_Id) REFERENCES employees12(emp_Id),job_id int,FOREIGN KEY(job_id) REFERENCES Jobdepartment1(job_id),salary_id int, FOREIGN KEY(salary_id) REFERENCES Salaryb(salary_id),leave_id int,foreign key(leave_id) references leave1(leave_id),date_in Date,report varchar(30),totalamount int);
drop table employees;
show tables;

